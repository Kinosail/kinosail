# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: subtitle-action-recovery.spec.ts >> dashboard restore response deadline preserves safe navigation at 1440px
- Location: e2e/subtitle-action-recovery.spec.ts:95:3

# Error details

```
Error: an uncertain write must stop occupying the global pending state

expect(locator).not.toHaveAttribute(expected) failed

Locator:  locator('[data-subtitle-action][data-api$="/restore"]')
Expected: not "true"
Received: "true"
Timeout:  1500ms

Call log:
  - an uncertain write must stop occupying the global pending state locator('[data-subtitle-action][data-api$="/restore"]') with timeout 1500ms
  - waiting for locator('[data-subtitle-action][data-api$="/restore"]')
    16 × locator resolved to <form method="post" aria-busy="true" data-subtitle-action="" action="/subtitles/manage/53ae726daeaed3fa/restore" data-api="/api/v1/subtitle-library/53ae726daeaed3fa/restore">…</form>
       - unexpected value "true"

```

```yaml
- button "Restore previous subtitle" [disabled]
```

# Test source

```ts
  5   | 
  6   | const fixtureRoot = process.env.KINOSAIL_SUBTITLE_ACTION_FIXTURE_DIR;
  7   | const revision = process.env.KINOSAIL_TEST_REVISION ?? execFileSync("git", ["rev-parse", "HEAD"], { encoding: "utf8" }).trim();
  8   | const origin = "http://subtitle-actions.test";
  9   | test.skip(!fixtureRoot, "requires real public Save/Restore control artifacts");
  10  | 
  11  | async function actionFixture(page: Page, testInfo: TestInfo, action: "save" | "restore", surface: "inspector" | "dashboard", completed: boolean) {
  12  |   const dir = `${fixtureRoot}/${action}`;
  13  |   const source = await readFile(`${dir}/${surface}.html`, "utf8");
  14  |   const historyPage = await readFile(`${dir}/history.html`, "utf8");
  15  |   const before = JSON.parse(await readFile(`${dir}/before.json`, "utf8"));
  16  |   const after = JSON.parse(await readFile(`${dir}/after.json`, "utf8"));
  17  |   const history = JSON.parse(await readFile(`${dir}/${completed ? "history" : "before-history"}.json`, "utf8"));
  18  |   const preview = action === "save" ? JSON.parse(await readFile(`${dir}/preview.json`, "utf8")) : null;
  19  |   const release: Array<() => void> = [];
  20  |   const requests = { mutations: [] as Array<{ path: string; input: unknown }>, inspections: 0, histories: 0, pages: 0 };
  21  |   const scripts = { inspector: await readFile(`${dir}/subtitle-inspector.js`), dashboard: await readFile(`${dir}/subtitle-status.js`) };
  22  |   await testInfo.attach("verification-context", { contentType: "application/json", body: JSON.stringify({ revision, action, surface, completed, width: page.viewportSize()?.width, command: "playwright test subtitle-action-recovery.spec.ts --workers=1", browserVersion: page.context().browser()?.version(), boundary: "isolated browser transport using actual public Go HTML/assets/Save/Restore reads; POST completion is represented by captured reads, not executed in this browser fixture; media aborted", sourceSHA256: createHash("sha256").update(scripts[surface]).digest("hex"), beforeFingerprint: before.fingerprint, afterFingerprint: after.fingerprint }) });
  23  |   await page.clock.install();
  24  |   await page.route(`${origin}/**`, async route => {
  25  |     const request = route.request(), url = new URL(request.url()), path = url.pathname;
  26  |     if (path.endsWith("/preview")) {
  27  |       expect(request.method()).toBe("POST");
  28  |       return route.fulfill({ json: preview });
  29  |     }
  30  |     if (request.method() === "POST") {
  31  |       requests.mutations.push({ path, input: request.postDataJSON() });
  32  |       await new Promise<void>(resolve => release.push(resolve));
  33  |       return route.abort().catch(() => {});
  34  |     }
  35  |     if (path.endsWith("/inspect")) {
  36  |       requests.inspections++;
  37  |       return route.fulfill({ json: completed && requests.mutations.length ? after : before });
  38  |     }
  39  |     if (path.endsWith("/draft")) return route.fulfill({ json: { state: "none", message: "No draft", words: [] } });
  40  |     if (path === "/api/v1/subtitle-library") {
  41  |       if (url.searchParams.get("view") === "history") { requests.histories++; return route.fulfill({ json: history }); }
  42  |       return route.fulfill({ json: { total: 1, ready: 1, wanted: 0, pending: 0, unavailable: 0 } });
  43  |     }
  44  |     if (path.startsWith("/media/")) return route.abort();
  45  |     const types: Record<string, string> = { "app.css": "text/css", "subtitle-inspector.css": "text/css", "subtitle-inspector.js": "text/javascript", "subtitle-status.js": "text/javascript", "theme.js": "text/javascript", "icon.svg": "image/svg+xml", "manrope.woff2": "font/woff2" };
  46  |     const name = path.split("/").pop() || "";
  47  |     if (types[name]) return route.fulfill({ contentType: types[name], body: await readFile(`${dir}/${name}`) });
  48  |     expect(request.method(), "recovery and navigation may only read").toBe("GET");
  49  |     requests.pages++;
  50  |     return route.fulfill({ contentType: "text/html", body: surface === "dashboard" && url.searchParams.get("view") === "history" ? historyPage : source });
  51  |   });
  52  |   await page.goto(`${origin}/${surface === "inspector" ? "subtitles/inspect/fixture" : "?view=library"}`);
  53  |   return {
  54  |     before, after, requests,
  55  |     async finish() {
  56  |       await testInfo.attach("action-requests", { contentType: "application/json", body: JSON.stringify(requests) });
  57  |       release.forEach(resolve => resolve());
  58  |     },
  59  |   };
  60  | }
  61  | 
  62  | async function beginInspectorAction(page: Page, action: "save" | "restore") {
  63  |   await expect(page.locator('#subtitle-edit-form [name="language"]')).toBeEnabled();
  64  |   if (action === "save") {
  65  |     await page.getByText("Timing anchors and cleanup", { exact: true }).click();
  66  |     await page.locator('[name="offset"]').fill("0.5");
  67  |     await page.getByRole("button", { name: "Preview changes", exact: true }).click();
  68  |     await expect(page.locator("#apply-subtitle")).toBeEnabled();
  69  |     await page.locator("#apply-subtitle").click();
  70  |   } else await page.locator("#restore-subtitle").click();
  71  |   await expect(page.locator('#subtitle-edit-form [name="language"]')).toBeDisabled();
  72  | }
  73  | 
  74  | for (const width of [390, 1440]) {
  75  |   for (const action of ["save", "restore"] as const) {
  76  |     test(`lost completed ${action} response recovers without replay at ${width}px`, { tag: "@smoke" }, async ({ page }, testInfo) => {
  77  |       await page.setViewportSize({ width, height: 900 });
  78  |       const fixture = await actionFixture(page, testInfo, action, "inspector", true);
  79  |       try {
  80  |         await beginInspectorAction(page, action);
  81  |         await expect.poll(() => fixture.requests.mutations.length).toBe(1);
  82  |         await page.clock.fastForward(45_000);
  83  |         await expect(page.locator('#subtitle-edit-form [name="language"]'), "a lost response must not lock the editor indefinitely").toBeEnabled({ timeout: 1500 });
  84  |         await expect.poll(() => fixture.requests.inspections, { timeout: 1500 }).toBeGreaterThan(1);
  85  |         await expect.poll(() => fixture.requests.histories, { timeout: 1500 }).toBeGreaterThan(0);
  86  |         await expect(page.locator("#inspector-status")).toContainText(action === "save" ? /saved|completed|installed/i : /restored|completed/i);
  87  |         await expect(page.locator("#apply-subtitle")).toBeDisabled();
  88  |         await page.clock.fastForward(60_000);
  89  |         expect(fixture.requests.mutations, "the completed mutation must never be retried automatically").toHaveLength(1);
  90  |         await page.screenshot({ path: testInfo.outputPath(`${action}-reconciled-${width}.png`), fullPage: true });
  91  |       } finally { await fixture.finish(); }
  92  |     });
  93  |   }
  94  | 
  95  |   test(`dashboard restore response deadline preserves safe navigation at ${width}px`, { tag: "@smoke" }, async ({ page }, testInfo) => {
  96  |     await page.setViewportSize({ width, height: 900 });
  97  |     const fixture = await actionFixture(page, testInfo, "restore", "dashboard", false);
  98  |     try {
  99  |       await page.locator(".subtitle-file > summary").click();
  100 |       const form = page.locator('[data-subtitle-action][data-api$="/restore"]');
  101 |       await form.getByRole("button", { name: "Restore previous subtitle", exact: true }).click();
  102 |       await expect(form).toHaveAttribute("aria-busy", "true");
  103 |       await expect.poll(() => fixture.requests.mutations.length).toBe(1);
  104 |       await page.clock.fastForward(45_000);
> 105 |       await expect(form, "an uncertain write must stop occupying the global pending state").not.toHaveAttribute("aria-busy", "true", { timeout: 1500 });
      |                                                                                                 ^ Error: an uncertain write must stop occupying the global pending state
  106 |       await expect(page.locator("#subtitle-feedback")).toContainText(/unknown|could not confirm|still|pending/i);
  107 |       await page.getByRole("link", { name: "History", exact: true }).click();
  108 |       await expect.poll(() => fixture.requests.pages).toBeGreaterThan(1);
  109 |       await expect(page.locator("#main")).toHaveAttribute("data-view", "history");
  110 |       await page.clock.fastForward(60_000);
  111 |       expect(fixture.requests.mutations, "read-only navigation must not replay Restore").toHaveLength(1);
  112 |       await page.screenshot({ path: testInfo.outputPath(`restore-unknown-dashboard-${width}.png`), fullPage: true });
  113 |     } finally { await fixture.finish(); }
  114 |   });
  115 | }
  116 | 
  117 | for (const action of ["save", "restore"] as const) {
  118 |   test(`still pending ${action} permits safe editing but blocks another write`, async ({ page }, testInfo) => {
  119 |     await page.setViewportSize({ width: 390, height: 900 });
  120 |     const fixture = await actionFixture(page, testInfo, action, "inspector", false);
  121 |     try {
  122 |       await beginInspectorAction(page, action);
  123 |       await expect.poll(() => fixture.requests.mutations.length).toBe(1);
  124 |       await page.clock.fastForward(45_000);
  125 |       await expect(page.locator('#subtitle-edit-form [name="language"]'), "safe editing must recover even when unchanged reads cannot confirm a write outcome").toBeEnabled({ timeout: 1500 });
  126 |       await expect(page.locator("#inspector-status")).toContainText(/unknown|could not confirm|still|pending/i);
  127 |       await expect(page.locator("#apply-subtitle")).toBeDisabled();
  128 |       await expect(page.locator("#restore-subtitle")).toBeDisabled();
  129 |       if (action === "save") await expect(page.locator('[name="offset"]')).toHaveValue("0.5");
  130 |       await page.clock.fastForward(60_000);
  131 |       expect(fixture.requests.mutations).toHaveLength(1);
  132 |     } finally { await fixture.finish(); }
  133 |   });
  134 | }
  135 | 
```