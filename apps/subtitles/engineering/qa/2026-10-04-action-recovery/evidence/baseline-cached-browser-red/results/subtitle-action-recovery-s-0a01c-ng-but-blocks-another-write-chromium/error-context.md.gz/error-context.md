# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: subtitle-action-recovery.spec.ts >> still pending restore permits safe editing but blocks another write
- Location: e2e/subtitle-action-recovery.spec.ts:118:3

# Error details

```
Error: safe editing must recover even when unchanged reads cannot confirm a write outcome

expect(locator).toBeEnabled() failed

Locator:  locator('#subtitle-edit-form [name="language"]')
Expected: enabled
Received: disabled
Timeout:  1500ms

Call log:
  - safe editing must recover even when unchanged reads cannot confirm a write outcome locator('#subtitle-edit-form [name="language"]') with timeout 1500ms
  - waiting for locator('#subtitle-edit-form [name="language"]')
    15 × locator resolved to <select disabled name="language">…</select>
       - unexpected value "disabled"

```

```yaml
- combobox "Subtitle language" [disabled]:
  - option "English (en)" [selected]
  - option "Spanish (es)"
  - option "Spanish (Latin America) (es-419)"
  - option "French (fr)"
  - option "German (de)"
  - option "Portuguese (Brazil) (pt-BR)"
  - option "Portuguese (Portugal) (pt-PT)"
  - option "Italian (it)"
  - option "Dutch (nl)"
  - option "Polish (pl)"
  - option "Russian (ru)"
  - option "Ukrainian (uk)"
  - option "Turkish (tr)"
  - option "Arabic (ar)"
  - option "Persian (fa)"
  - option "Hebrew (he)"
  - option "Hindi (hi)"
  - option "Bangla (bn)"
  - option "Urdu (ur)"
  - option "Indonesian (id)"
  - option "Malay (ms)"
  - option "Vietnamese (vi)"
  - option "Thai (th)"
  - option "Chinese (Simplified) (zh-Hans)"
  - option "Chinese (Traditional) (zh-Hant)"
  - option "Japanese (ja)"
  - option "Korean (ko)"
  - option "Filipino (fil)"
  - option "Filipino (tl)"
  - option "Tamil (ta)"
  - option "Telugu (te)"
  - option "Swahili (sw)"
  - option "Romanian (ro)"
  - option "Czech (cs)"
  - option "Slovak (sk)"
  - option "Hungarian (hu)"
  - option "Bulgarian (bg)"
  - option "Greek (el)"
  - option "Serbian (Cyrillic) (sr-Cyrl)"
  - option "Serbian (Latin) (sr-Latn)"
  - option "Croatian (hr)"
  - option "Bosnian (bs)"
  - option "Slovenian (sl)"
  - option "Macedonian (mk)"
  - option "Albanian (sq)"
  - option "Catalan (ca)"
  - option "Basque (eu)"
  - option "Galician (gl)"
  - option "Swedish (sv)"
  - option "Danish (da)"
  - option "Norwegian Bokmål (nb)"
  - option "Norwegian Nynorsk (nn)"
  - option "Finnish (fi)"
  - option "Icelandic (is)"
  - option "Estonian (et)"
  - option "Latvian (lv)"
  - option "Lithuanian (lt)"
  - option "Georgian (ka)"
  - option "Armenian (hy)"
  - option "Azerbaijani (az)"
  - option "Kazakh (kk)"
  - option "Uzbek (uz)"
  - option "Khmer (km)"
  - option "Burmese (my)"
  - option "Nepali (ne)"
  - option "Sinhala (si)"
  - option "Marathi (mr)"
  - option "Gujarati (gu)"
  - option "Punjabi (pa)"
  - option "Malayalam (ml)"
  - option "Kannada (kn)"
  - option "Amharic (am)"
  - option "Afrikaans (af)"
  - option "Abkhazian (ab)"
  - option "Afar (aa)"
  - option "Akan (ak)"
  - option "Akan (tw)"
  - option "Aragonese (an)"
  - option "Assamese (as)"
  - option "Asturian (ast)"
  - option "Avaric (av)"
  - option "Avestan (ae)"
  - option "Aymara (ay)"
  - option "Bambara (bm)"
  - option "Bashkir (ba)"
  - option "Belarusian (be)"
  - option "Bislama (bi)"
  - option "Breton (br)"
  - option "Cantonese (yue)"
  - option "Cebuano (ceb)"
  - option "Central Kurdish (ckb)"
  - option "Chamorro (ch)"
  - option "Chechen (ce)"
  - option "Chinese (zh)"
  - option "Church Slavic (cu)"
  - option "Chuvash (cv)"
  - option "Cornish (kw)"
  - option "Corsican (co)"
  - option "Cree (cr)"
  - option "Dari (prs)"
  - option "Divehi (dv)"
  - option "Dzongkha (dz)"
  - option "Esperanto (eo)"
  - option "Ewe (ee)"
  - option "Extremaduran (ext)"
  - option "Faroese (fo)"
  - option "Fijian (fj)"
  - option "Fulah (ff)"
  - option "Ganda (lg)"
  - option "Guarani (gn)"
  - option "Haitian Creole (ht)"
  - option "Hausa (ha)"
  - option "Herero (hz)"
  - option "Hiri Motu (ho)"
  - option "Ido (io)"
  - option "Igbo (ig)"
  - option "Interlingua (ia)"
  - option "Interlingue (ie)"
  - option "Inuktitut (iu)"
  - option "Inupiaq (ik)"
  - option "Irish (ga)"
  - option "Javanese (jv)"
  - option "Kalaallisut (kl)"
  - option "Kanuri (kr)"
  - option "Kashmiri (ks)"
  - option "Kikuyu (ki)"
  - option "Kinyarwanda (rw)"
  - option "Komi (kv)"
  - option "Kongo (kg)"
  - option "Kuanyama (kj)"
  - option "Kurdish (ku)"
  - option "Kyrgyz (ky)"
  - option "Lao (lo)"
  - option "Latin (la)"
  - option "Limburgish (li)"
  - option "Lingala (ln)"
  - option "Luba-Katanga (lu)"
  - option "Luxembourgish (lb)"
  - option "Malagasy (mg)"
  - option "Maltese (mt)"
  - option "Manipuri (mni)"
  - option "Manx (gv)"
  - option "Maori (mi)"
  - option "Marshallese (mh)"
  - option "Mongolian (mn)"
  - option "Montenegrin (cnr)"
  - option "Nauru (na)"
  - option "Navajo (nv)"
  - option "Ndonga (ng)"
  - option "North Ndebele (nd)"
  - option "Northern Sami (se)"
  - option "Norwegian Bokmål (no)"
  - option "Nyanja (ny)"
  - option "Occitan (oc)"
  - option "Odia (or)"
  - option "Ojibwa (oj)"
  - option "Oromo (om)"
  - option "Ossetic (os)"
  - option "Pali (pi)"
  - option "Pashto (ps)"
  - option "Portuguese (pt)"
  - option "Portuguese (Mozambique) (pt-MZ)"
  - option "Quechua (qu)"
  - option "Romansh (rm)"
  - option "Rundi (rn)"
  - option "Samoan (sm)"
  - option "Sango (sg)"
  - option "Sanskrit (sa)"
  - option "Santali (sat)"
  - option "Sardinian (sc)"
  - option "Scottish Gaelic (gd)"
  - option "Serbian (sr)"
  - option "Serbo-Croatian (sh)"
  - option "Shona (sn)"
  - option "Sichuan Yi (ii)"
  - option "Sindhi (sd)"
  - option "Somali (so)"
  - option "South Azerbaijani (azb)"
  - option "South Ndebele (nr)"
  - option "Southern Sotho (st)"
  - option "Spanish (Spain) (es-ES)"
  - option "Sundanese (su)"
  - option "Swati (ss)"
  - option "Syriac (syr)"
  - option "Tahitian (ty)"
  - option "Tajik (tg)"
  - option "Tatar (tt)"
  - option "Tetum (tet)"
  - option "Tibetan (bo)"
  - option "Tigrinya (ti)"
  - option "Toki Pona (tok)"
  - option "Tongan (to)"
  - option "Tsonga (ts)"
  - option "Tswana (tn)"
  - option "Turkmen (tk)"
  - option "Uyghur (ug)"
  - option "Venda (ve)"
  - option "Volapük (vo)"
  - option "Walloon (wa)"
  - option "Welsh (cy)"
  - option "Western Frisian (fy)"
  - option "Wolof (wo)"
  - option "Xhosa (xh)"
  - option "Yiddish (yi)"
  - option "Yoruba (yo)"
  - option "Zhuang (za)"
  - option "Zulu (zu)"
```

# Test source

```ts
  25  |     const request = route.request(), url = new URL(request.url()), path = url.pathname;
  26  |     if (path.endsWith("/preview")) {
  27  |       expect(request.method()).toBe("POST");
  28  |       return route.fulfill({ json: preview });
  29  |     }
  30  |     if (request.method() === "POST") {
  31  |       requests.mutations.push({ path, input: request.postDataJSON() });
  32  |       await new Promise<void>(resolve => release.push(resolve));
  33  |       return route.abort().catch(() => {});
  34  |     }
  35  |     if (path.endsWith("/inspect")) {
  36  |       requests.inspections++;
  37  |       return route.fulfill({ json: completed && requests.mutations.length ? after : before });
  38  |     }
  39  |     if (path.endsWith("/draft")) return route.fulfill({ json: { state: "none", message: "No draft", words: [] } });
  40  |     if (path === "/api/v1/subtitle-library") {
  41  |       if (url.searchParams.get("view") === "history") { requests.histories++; return route.fulfill({ json: history }); }
  42  |       return route.fulfill({ json: { total: 1, ready: 1, wanted: 0, pending: 0, unavailable: 0 } });
  43  |     }
  44  |     if (path.startsWith("/media/")) return route.abort();
  45  |     const types: Record<string, string> = { "app.css": "text/css", "subtitle-inspector.css": "text/css", "subtitle-inspector.js": "text/javascript", "subtitle-status.js": "text/javascript", "theme.js": "text/javascript", "icon.svg": "image/svg+xml", "manrope.woff2": "font/woff2" };
  46  |     const name = path.split("/").pop() || "";
  47  |     if (types[name]) return route.fulfill({ contentType: types[name], body: await readFile(`${dir}/${name}`) });
  48  |     expect(request.method(), "recovery and navigation may only read").toBe("GET");
  49  |     requests.pages++;
  50  |     return route.fulfill({ contentType: "text/html", body: surface === "dashboard" && url.searchParams.get("view") === "history" ? historyPage : source });
  51  |   });
  52  |   await page.goto(`${origin}/${surface === "inspector" ? "subtitles/inspect/fixture" : "?view=library"}`);
  53  |   return {
  54  |     before, after, requests,
  55  |     async finish() {
  56  |       await testInfo.attach("action-requests", { contentType: "application/json", body: JSON.stringify(requests) });
  57  |       release.forEach(resolve => resolve());
  58  |     },
  59  |   };
  60  | }
  61  | 
  62  | async function beginInspectorAction(page: Page, action: "save" | "restore") {
  63  |   await expect(page.locator('#subtitle-edit-form [name="language"]')).toBeEnabled();
  64  |   if (action === "save") {
  65  |     await page.getByText("Timing anchors and cleanup", { exact: true }).click();
  66  |     await page.locator('[name="offset"]').fill("0.5");
  67  |     await page.getByRole("button", { name: "Preview changes", exact: true }).click();
  68  |     await expect(page.locator("#apply-subtitle")).toBeEnabled();
  69  |     await page.locator("#apply-subtitle").click();
  70  |   } else await page.locator("#restore-subtitle").click();
  71  |   await expect(page.locator('#subtitle-edit-form [name="language"]')).toBeDisabled();
  72  | }
  73  | 
  74  | for (const width of [390, 1440]) {
  75  |   for (const action of ["save", "restore"] as const) {
  76  |     test(`lost completed ${action} response recovers without replay at ${width}px`, { tag: "@smoke" }, async ({ page }, testInfo) => {
  77  |       await page.setViewportSize({ width, height: 900 });
  78  |       const fixture = await actionFixture(page, testInfo, action, "inspector", true);
  79  |       try {
  80  |         await beginInspectorAction(page, action);
  81  |         await expect.poll(() => fixture.requests.mutations.length).toBe(1);
  82  |         await page.clock.fastForward(45_000);
  83  |         await expect(page.locator('#subtitle-edit-form [name="language"]'), "a lost response must not lock the editor indefinitely").toBeEnabled({ timeout: 1500 });
  84  |         await expect.poll(() => fixture.requests.inspections, { timeout: 1500 }).toBeGreaterThan(1);
  85  |         await expect.poll(() => fixture.requests.histories, { timeout: 1500 }).toBeGreaterThan(0);
  86  |         await expect(page.locator("#inspector-status")).toContainText(action === "save" ? /saved|completed|installed/i : /restored|completed/i);
  87  |         await expect(page.locator("#apply-subtitle")).toBeDisabled();
  88  |         await page.clock.fastForward(60_000);
  89  |         expect(fixture.requests.mutations, "the completed mutation must never be retried automatically").toHaveLength(1);
  90  |         await page.screenshot({ path: testInfo.outputPath(`${action}-reconciled-${width}.png`), fullPage: true });
  91  |       } finally { await fixture.finish(); }
  92  |     });
  93  |   }
  94  | 
  95  |   test(`dashboard restore response deadline preserves safe navigation at ${width}px`, { tag: "@smoke" }, async ({ page }, testInfo) => {
  96  |     await page.setViewportSize({ width, height: 900 });
  97  |     const fixture = await actionFixture(page, testInfo, "restore", "dashboard", false);
  98  |     try {
  99  |       await page.locator(".subtitle-file > summary").click();
  100 |       const form = page.locator('[data-subtitle-action][data-api$="/restore"]');
  101 |       await form.getByRole("button", { name: "Restore previous subtitle", exact: true }).click();
  102 |       await expect(form).toHaveAttribute("aria-busy", "true");
  103 |       await expect.poll(() => fixture.requests.mutations.length).toBe(1);
  104 |       await page.clock.fastForward(45_000);
  105 |       await expect(form, "an uncertain write must stop occupying the global pending state").not.toHaveAttribute("aria-busy", "true", { timeout: 1500 });
  106 |       await expect(page.locator("#subtitle-feedback")).toContainText(/unknown|could not confirm|still|pending/i);
  107 |       await page.getByRole("link", { name: "History", exact: true }).click();
  108 |       await expect.poll(() => fixture.requests.pages).toBeGreaterThan(1);
  109 |       await expect(page.locator("#main")).toHaveAttribute("data-view", "history");
  110 |       await page.clock.fastForward(60_000);
  111 |       expect(fixture.requests.mutations, "read-only navigation must not replay Restore").toHaveLength(1);
  112 |       await page.screenshot({ path: testInfo.outputPath(`restore-unknown-dashboard-${width}.png`), fullPage: true });
  113 |     } finally { await fixture.finish(); }
  114 |   });
  115 | }
  116 | 
  117 | for (const action of ["save", "restore"] as const) {
  118 |   test(`still pending ${action} permits safe editing but blocks another write`, async ({ page }, testInfo) => {
  119 |     await page.setViewportSize({ width: 390, height: 900 });
  120 |     const fixture = await actionFixture(page, testInfo, action, "inspector", false);
  121 |     try {
  122 |       await beginInspectorAction(page, action);
  123 |       await expect.poll(() => fixture.requests.mutations.length).toBe(1);
  124 |       await page.clock.fastForward(45_000);
> 125 |       await expect(page.locator('#subtitle-edit-form [name="language"]'), "safe editing must recover even when unchanged reads cannot confirm a write outcome").toBeEnabled({ timeout: 1500 });
      |                                                                                                                                                                 ^ Error: safe editing must recover even when unchanged reads cannot confirm a write outcome
  126 |       await expect(page.locator("#inspector-status")).toContainText(/unknown|could not confirm|still|pending/i);
  127 |       await expect(page.locator("#apply-subtitle")).toBeDisabled();
  128 |       await expect(page.locator("#restore-subtitle")).toBeDisabled();
  129 |       if (action === "save") await expect(page.locator('[name="offset"]')).toHaveValue("0.5");
  130 |       await page.clock.fastForward(60_000);
  131 |       expect(fixture.requests.mutations).toHaveLength(1);
  132 |     } finally { await fixture.finish(); }
  133 |   });
  134 | }
  135 | 
```