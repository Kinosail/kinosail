# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: player-subtitles-lifecycle.spec.ts >> persisted caption restore cancels the old attempt and reloads the selected language
- Location: player-subtitles-lifecycle.spec.ts:7:1

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: "Recovered captions"
Received: undefined

Call Log:
- Timeout 2000ms exceeded while waiting on the predicate
```

# Page snapshot

```yaml
- generic [active] [ref=e1]:
  - generic "Fixture video" [ref=e2]
  - generic [ref=e3]:
    - text: Subtitles
    - combobox "Subtitles" [ref=e4]:
      - option "English" [selected]
      - option "Off"
  - status [ref=e5]: Loading subtitles…
```

# Test source

```ts
  1  | import { expect, test } from "@playwright/test";
  2  | import { captionPeer, isolated, openCaptionPlayer, serverOrigin } from "./player-subtitles-recovery-fixture";
  3  | 
  4  | test.skip(!isolated || Boolean(serverOrigin), "isolated native PageTransitionEvent control for persisted caption lifecycle");
  5  | test.use({ serviceWorkers: "block" });
  6  | 
  7  | test("persisted caption restore cancels the old attempt and reloads the selected language", async ({page}, info) => {
  8  |   const peer = await captionPeer(page, "body");
  9  |   try {
  10 |     await openCaptionPlayer(page, peer.origin);
  11 |     await expect(page.locator("[data-subtitle-status]")).toHaveText("Loading subtitles…");
  12 |     await expect.poll(async () => (await peer.stats()).calls).toBe(1);
  13 |     await page.evaluate(() => dispatchEvent(new PageTransitionEvent("pagehide", {persisted: true})));
  14 |     await expect.poll(async () => (await peer.stats()).closed).toBe(1);
  15 |     await expect(page.locator("track")).not.toHaveAttribute("src", /.+/);
  16 |     await page.evaluate(() => dispatchEvent(new PageTransitionEvent("pageshow", {persisted: true})));
  17 |     await info.attach("transport-after-persisted-restore", {body: JSON.stringify(await peer.stats()), contentType: "application/json"});
> 18 |     await expect.poll(() => page.locator('track[srclang="en"]').evaluate((track: HTMLTrackElement) => (track.track.cues?.[0] as VTTCue | undefined)?.text), {timeout: 2_000}).toBe("Recovered captions");
     |                                                                                                                                                                               ^ Error: expect(received).toBe(expected) // Object.is equality
  19 |     await expect(page.locator("[data-subtitle-status]")).toBeHidden();
  20 |     await expect(page.locator("[data-subtitle-retry]")).toBeHidden();
  21 |     expect(await page.locator("track").evaluate((track: HTMLTrackElement) => track.track.mode)).toBe("showing");
  22 |     expect((await peer.stats()).calls).toBe(2);
  23 |     await page.clock.fastForward(25_000);
  24 |     await expect(page.locator("[data-subtitle-status]")).toBeHidden();
  25 |     await page.screenshot({path: info.outputPath("persisted-selected-recovered.png"), fullPage: true});
  26 |   } finally {
  27 |     await peer.close();
  28 |   }
  29 | });
  30 | 
  31 | test("persisted caption restore keeps Off without starting another request", async ({page}, info) => {
  32 |   const peer = await captionPeer(page, "headers");
  33 |   try {
  34 |     await openCaptionPlayer(page, peer.origin);
  35 |     await expect(page.locator("[data-subtitle-status]")).toHaveText("Loading subtitles…");
  36 |     await expect.poll(async () => (await peer.stats()).calls).toBe(1);
  37 |     // Isolated shell has no settings adapter; operate the native track preference.
  38 |     await page.locator("track").evaluate((track: HTMLTrackElement) => { track.track.mode = "disabled"; });
  39 |     await page.locator("[data-subtitles]").selectOption("off");
  40 |     await expect(page.locator("[data-subtitle-status]")).toBeHidden();
  41 |     await page.evaluate(() => dispatchEvent(new PageTransitionEvent("pagehide", {persisted: true})));
  42 |     await expect.poll(async () => (await peer.stats()).closed).toBe(1);
  43 |     await page.evaluate(() => dispatchEvent(new PageTransitionEvent("pageshow", {persisted: true})));
  44 |     await page.clock.fastForward(25_000);
  45 |     await expect(page.locator("[data-subtitle-status]")).toBeHidden();
  46 |     await expect(page.locator("[data-subtitle-retry]")).toBeHidden();
  47 |     await expect(page.locator("[data-subtitles]")).toHaveValue("off");
  48 |     expect(await page.locator("track").evaluate((track: HTMLTrackElement) => track.track.mode)).toBe("disabled");
  49 |     await expect(page.locator("track")).not.toHaveAttribute("src", /.+/);
  50 |     expect((await peer.stats()).calls).toBe(1);
  51 |     await page.screenshot({path: info.outputPath("persisted-off.png"), fullPage: true});
  52 |   } finally {
  53 |     await peer.close();
  54 |   }
  55 | });
  56 | 
```