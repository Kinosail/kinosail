# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: player-subtitles-recovery.spec.ts >> isolated transport: stalled caption body reaches a deadline and keyboard Retry at 390px
- Location: player-subtitles-recovery.spec.ts:9:3

# Error details

```
Error: expect(locator).toContainText(expected) failed

Locator: locator('[data-subtitle-status]')
Expected substring: "Subtitles unavailable"
Received string:    "Loading subtitles…"
Timeout: 2000ms

Call log:
  - Expect "toContainText" locator('[data-subtitle-status]') with timeout 2000ms
  - waiting for locator('[data-subtitle-status]')
    21 × locator resolved to <small role="status" data-subtitle-status="">Loading subtitles…</small>
       - unexpected value "Loading subtitles…"

```

```yaml
- status: Loading subtitles…
```

# Test source

```ts
  1  | import { expect, test } from "@playwright/test";
  2  | import { captionPeer, isolated, openCaptionPlayer, serverOrigin } from "./player-subtitles-recovery-fixture";
  3  | 
  4  | test.skip(!serverOrigin && !isolated, "requires the opt-in disposable Server runner or explicit isolated transport control");
  5  | test.use({ serviceWorkers: "block" });
  6  | 
  7  | for (const width of serverOrigin ? [390, 1440, 1920] : [390]) {
  8  | for (const stalledBoundary of ["headers", "body"] as const) {
  9  |   test(`${serverOrigin ? "real Server" : "isolated transport"}: stalled caption ${stalledBoundary} reaches a deadline and keyboard Retry at ${width}px`, async ({ page }, info) => {
  10 |     await page.setViewportSize({width, height: width === 1920 ? 1080 : 844});
  11 |     const peer = await captionPeer(page, stalledBoundary);
  12 |     try {
  13 |       const servedBundle = await openCaptionPlayer(page, peer.origin);
  14 |       if (servedBundle) await info.attach("served-player-bundle-identity", {body: JSON.stringify(servedBundle), contentType: "application/json"});
  15 |       await expect(page.locator("[data-subtitle-status]")).toHaveText("Loading subtitles…");
  16 |       await expect.poll(async () => (await peer.stats()).calls).toBe(1);
  17 |       const before = await page.locator("video").evaluate((video: HTMLVideoElement) => ({source: video.getAttribute("src"), time: video.currentTime, paused: video.paused}));
  18 |       await page.screenshot({path: info.outputPath(`${stalledBoundary}-${width}-pending.png`), fullPage: true});
  19 |       await page.clock.fastForward(20_100);
  20 |       await page.screenshot({ path: info.outputPath(`${stalledBoundary}-after-deadline.png`) });
> 21 |       await expect(page.locator("[data-subtitle-status]")).toContainText("Subtitles unavailable", { timeout: 2_000 });
     |                                                            ^ Error: expect(locator).toContainText(expected) failed
  22 |       await expect(page.locator("[data-subtitle-status]")).toHaveAttribute("data-failure", "timeout");
  23 |       if (stalledBoundary === "body") await expect(page.locator("[data-subtitle-status]")).toHaveAttribute("data-request-id", "caption-fixture-1");
  24 |       else await expect(page.locator("[data-subtitle-status]")).not.toHaveAttribute("data-request-id");
  25 |       await expect.poll(async () => (await peer.stats()).closed).toBe(1);
  26 |       const retry = page.getByRole("button", { name: "Retry subtitles" });
  27 |       await expect(retry).toBeVisible();
  28 |       await retry.focus();
  29 |       await page.keyboard.press("Enter");
  30 |       await expect.poll(() => page.locator('track[srclang="en"]').evaluate((track: HTMLTrackElement) => (track.track.cues?.[0] as VTTCue | undefined)?.text)).toBe("Recovered captions");
  31 |       await expect(page.locator("[data-subtitle-status]")).toBeHidden();
  32 |       await expect(retry).toBeHidden();
  33 |       await expect(page.locator("[data-subtitles]")).toBeFocused();
  34 |       await expect(page.locator("[data-subtitles]")).toHaveValue("0");
  35 |       await page.clock.fastForward(25_000);
  36 |       await expect(page.locator("[data-subtitle-status]")).toBeHidden();
  37 |       await expect(page.locator("[data-subtitle-status]")).not.toHaveAttribute("data-failure");
  38 |       await expect(page.locator("[data-subtitle-status]")).not.toHaveAttribute("data-request-id");
  39 |       expect(await page.locator('track[srclang="en"]').evaluate((track: HTMLTrackElement) => track.track.mode)).toBe("showing");
  40 |       const after = await page.locator("video").evaluate((video: HTMLVideoElement) => ({source: video.getAttribute("src"), time: video.currentTime, paused: video.paused}));
  41 |       expect(after.source).toBe(before.source);
  42 |       expect(after.paused).toBe(before.paused);
  43 |       if (serverOrigin) {
  44 |         await expect.poll(() => page.locator("video").evaluate((video: HTMLVideoElement) => video.currentTime)).toBeGreaterThan(before.time + 0.1);
  45 |         await page.screenshot({ path: info.outputPath(`${stalledBoundary}-recovered.png`), fullPage: true });
  46 |       } else expect(after.time).toBe(before.time);
  47 |       expect((await peer.stats()).calls).toBe(2);
  48 |       if (serverOrigin) {
  49 |         await page.locator("[data-subtitles]").selectOption("off");
  50 |         await expect(page.locator("[data-subtitle-status]")).toBeHidden();
  51 |         await expect(retry).toBeHidden();
  52 |         expect(await page.locator('track[srclang="en"]').evaluate((track: HTMLTrackElement) => track.track.mode)).toBe("disabled");
  53 |         await page.screenshot({path: info.outputPath(`${stalledBoundary}-${width}-off.png`), fullPage: true});
  54 |       }
  55 |     } finally {
  56 |       await peer.close();
  57 |     }
  58 |   });
  59 | }
  60 | }
  61 | 
```