# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: download-pause.spec.ts >> isolated native browser: Pause retains verified indexeddb blocks and Resume continues missing ranges at 1440px
- Location: download-pause.spec.ts:9:3

# Error details

```
Error: expect(locator).toBeEnabled() failed

Locator: getByRole('button', { name: 'Pause download', exact: true })
Expected: enabled
Timeout: 2000ms
Error: element(s) not found

Call log:
  - Expect "toBeEnabled" getByRole('button', { name: 'Pause download', exact: true }) with timeout 2000ms
  - waiting for getByRole('button', { name: 'Pause download', exact: true })

```

```yaml
- main:
  - heading "Offline downloads" [level=1]
  - paragraph: Prepared files are private to this Viewer Profile.
  - article:
    - heading "Fictional Range Fixture" [level=2]
    - paragraph: original Â· Ready to download
    - button "Download to this device" [disabled]
    - status: 49% stored on this device Â· Keep this page open
    - group: Remove download
```

# Test source

```ts
  1  | import { expect, test } from "@playwright/test";
  2  | import { downloadChunk, downloadBytes, downloadHash, firstBlockHash, downloadIsolated, downloadServer, downloadPeer, openDownloadPage, inspectDownload } from "./download-pause-fixture";
  3  | 
  4  | test.skip(!downloadServer && !downloadIsolated, "requires an explicit disposable download transport runner");
  5  | test.use({serviceWorkers: "allow"});
  6  | 
  7  | for (const storage of ["opfs", "indexeddb"] as const) {
  8  | for (const width of downloadServer ? [390, 1440, 1920] : [storage === "opfs" ? 390 : 1440]) {
  9  |   test(`${downloadServer ? "real Server" : "isolated native browser"}: Pause retains verified ${storage} blocks and Resume continues missing ranges at ${width}px`, async ({page, context}, info) => {
  10 |     test.setTimeout(60_000);
  11 |     await page.setViewportSize({width, height: width === 1920 ? 1080 : 844});
  12 |     const peer = await downloadPeer();
  13 |     try {
  14 |       const served = await openDownloadPage(page, peer.origin, storage);
  15 |       await info.attach("served-download-bundle", {body: JSON.stringify(served), contentType: "application/json"});
  16 |       const button = page.locator("[data-download-device]"), status = page.locator("[data-download-device-status]");
  17 |       await expect(status).toHaveText("Not stored on this device");
  18 |       await button.click();
  19 |       await expect.poll(async () => (await peer.stats()).ranges).toEqual([0, downloadChunk]);
  20 |       await expect.poll(async () => (await inspectDownload(page, served.jobID)).job?.bytes).toBe(downloadChunk);
  21 |       await expect(status).toContainText("Keep this page open");
  22 |       const before = await inspectDownload(page, served.jobID);
  23 |       expect(before.job?.storage).toBe(storage);
  24 |       expect(before.chunks).toEqual([{offset: 0, length: downloadChunk, sha256: firstBlockHash, actual: firstBlockHash}]);
  25 |       await info.attach("verified-first-block-before-pause", {body: JSON.stringify(before), contentType: "application/json"});
  26 |       await page.screenshot({path: info.outputPath(`${storage}-${width}-pending.png`), fullPage: true});
  27 |       const pause = page.getByRole("button", {name: "Pause download", exact: true});
> 28 |       await expect(pause).toBeEnabled({timeout: 2_000});
     |                           ^ Error: expect(locator).toBeEnabled() failed
  29 |       await pause.focus(); await page.keyboard.press("Enter");
  30 |       const resume = page.getByRole("button", {name: "Resume on this device", exact: true});
  31 |       await expect(resume).toBeEnabled();
  32 |       await expect(resume).toBeFocused();
  33 |       await expect(status).toHaveText("Download paused. Resume to continue where it stopped.");
  34 |       await expect.poll(async () => (await peer.stats()).closed).toBe(1);
  35 |       const paused = await inspectDownload(page, served.jobID);
  36 |       expect(paused.job?.readyOffline).toBe(false);
  37 |       expect(paused.job?.bytes).toBe(downloadChunk);
  38 |       expect(paused.chunks).toEqual(before.chunks);
  39 |       expect(paused.fileSize).toBe(downloadChunk);
  40 |       expect(paused.fileHash).toBe(firstBlockHash);
  41 |       expect(paused.locks.filter((name) => name.startsWith("kinosail-offline"))).toEqual([]);
  42 |       await info.attach("paused-verified-storage-and-peer", {body: JSON.stringify({stored: paused, peer: await peer.stats()}), contentType: "application/json"});
  43 |       await page.screenshot({path: info.outputPath(`${storage}-${width}-paused.png`), fullPage: true});
  44 |       // A failed offline Resume must leave retained blocks available for recovery.
  45 |       await context.setOffline(true); await resume.click();
  46 |       await expect(resume).toBeEnabled();
  47 |       await expect(status).not.toHaveText("Download paused. Resume to continue where it stopped.");
  48 |       expect((await inspectDownload(page, served.jobID)).chunks).toEqual(before.chunks);
  49 |       await page.screenshot({path: info.outputPath(`${storage}-${width}-offline-failure.png`), fullPage: true});
  50 |       await context.setOffline(false); await resume.focus(); await page.keyboard.press("Enter");
  51 |       await expect(status).toHaveText("Saved and verified. Play to check compatibility.", {timeout: 25_000});
  52 |       const ready = await inspectDownload(page, served.jobID);
  53 |       expect(ready.job?.readyOffline).toBe(true);
  54 |       expect(ready.job?.state).toBe("ready");
  55 |       expect(ready.job?.sha256).toBe(downloadHash);
  56 |       expect(ready.fileSize).toBe(downloadBytes.length);
  57 |       expect(ready.fileHash).toBe(downloadHash);
  58 |       expect(ready.job?.transferID).not.toBe(paused.job?.transferID);
  59 |       expect(ready.job?.profileID).toBe(paused.job?.profileID);
  60 |       expect(ready.job?.itemID).toBe(paused.job?.itemID);
  61 |       expect((await peer.stats()).ranges).toEqual([0, downloadChunk, downloadChunk, downloadChunk * 2]);
  62 |       expect((await peer.stats()).removals).toBe(0);
  63 |       await expect(page.locator("[data-download-play]")).toBeVisible();
  64 |       await expect(page.getByRole("button", {name: "Pause download", exact: true})).toHaveCount(0);
  65 |       const serverJob = await page.request.get(`${peer.origin}/api/v1/downloads/${served.jobID}`);
  66 |       expect(serverJob.ok()).toBe(true);
  67 |       expect(await serverJob.json()).toMatchObject({state: "ready", readyOffline: true, sha256: downloadHash});
  68 |       await info.attach("resumed-integrity-and-ranges", {body: JSON.stringify({stored: ready, peer: await peer.stats()}), contentType: "application/json"});
  69 |       await page.screenshot({path: info.outputPath(`${storage}-${width}-ready.png`), fullPage: true});
  70 |     } finally { await context.setOffline(false); await peer.close(); }
  71 |   });
  72 | }
  73 | }
  74 | 
```