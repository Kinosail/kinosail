# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: download-pause.spec.ts >> isolated native browser: Pause retains verified opfs blocks and Resume continues missing ranges at 390px
- Location: download-pause.spec.ts:10:3

# Error details

```
Error: expect(locator).toBeEnabled() failed

Locator: getByRole('button', { name: 'Pause download', exact: true })
Expected: enabled
Timeout: 2000ms
Error: element(s) not found

Call log:
  - Expect "toBeEnabled" getByRole('button', { name: 'Pause download', exact: true }) with timeout 2000ms
  - waiting for getByRole('button', { name: 'Pause download', exact: true })

```

```yaml
- main:
  - heading "Offline downloads" [level=1]
  - paragraph: Prepared files are private to this Viewer Profile.
  - article:
    - heading "Fictional Range Fixture" [level=2]
    - paragraph: original · Ready to download
    - button "Download to this device" [disabled]
    - status: 49% stored on this device · Keep this page open
    - group: Remove download
```

# Test source

```ts
  1  | import { expect, test } from "@playwright/test";
  2  | import { downloadChunk, downloadBytes, downloadHash, firstBlockHash, downloadIsolated, downloadServer, downloadPeer, openDownloadPage, inspectDownload, attachDownloadEnvironment } from "./download-pause-fixture";
  3  | 
  4  | test.skip(!downloadServer && !downloadIsolated, "requires an explicit disposable download transport runner");
  5  | test.use({serviceWorkers: "allow"});
  6  | test.beforeEach(async ({browser}, info) => attachDownloadEnvironment(browser, info));
  7  | 
  8  | for (const storage of ["opfs", "indexeddb"] as const) {
  9  | for (const width of downloadServer ? [390, 1440, 1920] : [storage === "opfs" ? 390 : 1440]) {
  10 |   test(`${downloadServer ? "real Server" : "isolated native browser"}: Pause retains verified ${storage} blocks and Resume continues missing ranges at ${width}px`, async ({page, context}, info) => {
  11 |     test.setTimeout(60_000);
  12 |     await page.setViewportSize({width, height: width === 1920 ? 1080 : 844});
  13 |     const peer = await downloadPeer();
  14 |     try {
  15 |       const served = await openDownloadPage(page, peer.origin, storage);
  16 |       await info.attach("served-download-bundle", {body: JSON.stringify(served), contentType: "application/json"});
  17 |       const button = page.locator("[data-download-device]"), status = page.locator("[data-download-device-status]");
  18 |       await expect(status).toHaveText("Not stored on this device");
  19 |       await button.click();
  20 |       await expect.poll(async () => (await peer.stats()).ranges).toEqual([0, downloadChunk]);
  21 |       await expect.poll(async () => (await inspectDownload(page, served.jobID)).job?.bytes).toBe(downloadChunk);
  22 |       await expect(status).toContainText("Keep this page open");
  23 |       const before = await inspectDownload(page, served.jobID);
  24 |       expect(before.job?.storage).toBe(storage);
  25 |       expect(before.chunks).toEqual([{offset: 0, length: downloadChunk, sha256: firstBlockHash, actual: firstBlockHash}]);
  26 |       await info.attach("verified-first-block-before-pause", {body: JSON.stringify(before), contentType: "application/json"});
  27 |       await page.screenshot({path: info.outputPath(`${storage}-${width}-pending.png`), fullPage: true});
  28 |       const pause = page.getByRole("button", {name: "Pause download", exact: true});
> 29 |       await expect(pause).toBeEnabled({timeout: 2_000});
     |                           ^ Error: expect(locator).toBeEnabled() failed
  30 |       await pause.focus(); await page.keyboard.press("Enter");
  31 |       const resume = page.getByRole("button", {name: "Resume on this device", exact: true});
  32 |       await expect(resume).toBeEnabled();
  33 |       await expect(resume).toBeFocused();
  34 |       await expect(status).toHaveText("Download paused. Resume to continue where it stopped.");
  35 |       await expect.poll(async () => (await peer.stats()).closed).toBe(1);
  36 |       const paused = await inspectDownload(page, served.jobID);
  37 |       expect(paused.job?.readyOffline).toBe(false);
  38 |       expect(paused.job?.bytes).toBe(downloadChunk);
  39 |       expect(paused.chunks).toEqual(before.chunks);
  40 |       expect(paused.fileSize).toBe(downloadChunk);
  41 |       expect(paused.fileHash).toBe(firstBlockHash);
  42 |       expect(paused.locks.filter((name) => name.startsWith("kinosail-offline"))).toEqual([]);
  43 |       await info.attach("paused-verified-storage-and-peer", {body: JSON.stringify({stored: paused, peer: await peer.stats()}), contentType: "application/json"});
  44 |       await page.screenshot({path: info.outputPath(`${storage}-${width}-paused.png`), fullPage: true});
  45 |       // A failed offline Resume must leave retained blocks available for recovery.
  46 |       await context.setOffline(true); await resume.click();
  47 |       await expect(resume).toBeEnabled();
  48 |       await expect(status).not.toHaveText("Download paused. Resume to continue where it stopped.");
  49 |       expect((await inspectDownload(page, served.jobID)).chunks).toEqual(before.chunks);
  50 |       await page.screenshot({path: info.outputPath(`${storage}-${width}-offline-failure.png`), fullPage: true});
  51 |       await context.setOffline(false); await resume.focus(); await page.keyboard.press("Enter");
  52 |       await expect(status).toHaveText("Saved and verified. Play to check compatibility.", {timeout: 25_000});
  53 |       const ready = await inspectDownload(page, served.jobID);
  54 |       expect(ready.job?.readyOffline).toBe(true);
  55 |       expect(ready.job?.state).toBe("ready");
  56 |       expect(ready.job?.sha256).toBe(downloadHash);
  57 |       expect(ready.fileSize).toBe(downloadBytes.length);
  58 |       expect(ready.fileHash).toBe(downloadHash);
  59 |       expect(ready.job?.transferID).not.toBe(paused.job?.transferID);
  60 |       expect(ready.job?.profileID).toBe(paused.job?.profileID);
  61 |       expect(ready.job?.itemID).toBe(paused.job?.itemID);
  62 |       expect((await peer.stats()).ranges).toEqual([0, downloadChunk, downloadChunk, downloadChunk * 2]);
  63 |       expect((await peer.stats()).removals).toBe(0);
  64 |       await expect(page.locator("[data-download-play]")).toBeVisible();
  65 |       await expect(page.getByRole("button", {name: "Pause download", exact: true})).toHaveCount(0);
  66 |       const serverJob = await page.request.get(`${peer.origin}/api/v1/downloads/${served.jobID}`);
  67 |       expect(serverJob.ok()).toBe(true);
  68 |       expect(await serverJob.json()).toMatchObject({state: "ready", readyOffline: true, sha256: downloadHash});
  69 |       await info.attach("resumed-integrity-and-ranges", {body: JSON.stringify({stored: ready, peer: await peer.stats()}), contentType: "application/json"});
  70 |       await page.screenshot({path: info.outputPath(`${storage}-${width}-ready.png`), fullPage: true});
  71 |     } finally { await context.setOffline(false); await context.close(); await peer.close(); }
  72 |   });
  73 | }
  74 | }
  75 | 
```