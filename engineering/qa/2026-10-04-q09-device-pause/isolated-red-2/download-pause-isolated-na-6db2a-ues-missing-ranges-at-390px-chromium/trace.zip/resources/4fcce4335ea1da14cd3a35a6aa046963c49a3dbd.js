(() => {
  if (window.kinosailOfflineIdentity) return;
  const key = "kinosail.offline-identity-v1";
  let selected = {profile: "", revision: 0};
  const state = () => {
    try {
      const saved = JSON.parse(localStorage.getItem(key) || "null");
      if (saved && typeof saved.profile === "string" && /^[A-Za-z0-9_-]{0,128}$/.test(saved.profile) && Number.isSafeInteger(saved.revision) && saved.revision > selected.revision && saved.revision <= Date.now() + 60000) return saved;
    } catch {}
    return selected;
  };
  const update = (next) => {
    if (next.revision <= state().revision) return;
    selected = next;
    try { localStorage.setItem(key, JSON.stringify(next)); localStorage.setItem("kinosail.offline-profile", next.profile); } catch {}
    window.dispatchEvent(new Event("kinosail:offline-profile"));
  };
  const select = (profile) => update({profile, revision: Math.max(Date.now(), state().revision + 1)});
  window.kinosailOfflineIdentity = {current: () => state().profile, state};
  const profile = document.body.dataset.viewerProfile || document.querySelector("[data-nav-profile]")?.dataset.navProfile || document.querySelector("#downloads")?.dataset.viewerProfile;
  if (profile) select(profile);
  navigator.serviceWorker?.addEventListener("message", ({data}) => {
    if (data?.type === "offline-profile" && typeof data.profile === "string" && Number.isSafeInteger(data.revision)) update({profile: data.profile, revision: data.revision});
  });
  document.addEventListener("submit", ({target}) => {
    if (target instanceof HTMLFormElement && new URL(target.action, location.href).pathname === "/logout") {
      select("");
      navigator.serviceWorker?.controller?.postMessage({type: "logout", ...state()});
    }
  }, true);
  window.addEventListener("storage", (event) => {
    if (event.key === key) window.dispatchEvent(new Event("kinosail:offline-profile"));
  });
})();
const openOfflineDatabaseConnection = () => new Promise((resolve, reject) => {
  const request = indexedDB.open(offlineDatabase, 4);
  request.onupgradeneeded = () => {
    const database = request.result;
    if (!database.objectStoreNames.contains("identity")) database.createObjectStore("identity");
    if (!database.objectStoreNames.contains("jobs")) database.createObjectStore("jobs", {keyPath: "id"});
    const chunks = database.objectStoreNames.contains("chunks") ? request.transaction.objectStore("chunks") : database.createObjectStore("chunks", {keyPath: "id"});
    if (!chunks.indexNames.contains("jobID")) chunks.createIndex("jobID", "jobID");
    if (!chunks.indexNames.contains("jobRange")) chunks.createIndex("jobRange", ["jobID", "offset"]);
  };
  request.onsuccess = () => resolve(request.result);
  request.onerror = () => reject(request.error);
});
const offlineDatabase = "kinosail-offline-v1";
const chunkSize = 8 * 1024 * 1024;
const offlineIntegrityVersion = 2;
const hasOfflineStorage = "indexedDB" in window && "crypto" in window && Boolean(window.crypto.subtle);
let offlineChannel;
const offlineWorkerPath = "/service-worker.js?v=55";
const offlineWorkerURL = new URL(offlineWorkerPath, location.href).href;
const isExactOfflineWorker = (worker) => worker?.scriptURL === offlineWorkerURL && worker.state === "activated";
const currentOfflineServiceWorker = async () => {
  try {
    const registration = await navigator.serviceWorker.getRegistration();
    return registration && isExactOfflineWorker(registration.active) && isExactOfflineWorker(navigator.serviceWorker.controller) ? registration : undefined;
  } catch (_) { return; }
};
const activateOfflineServiceWorker = async (registration) => {
  let worker = [registration.installing, registration.waiting, registration.active].find((candidate) => candidate?.scriptURL === offlineWorkerURL);
  if (!worker) {
    await new Promise((resolve) => {
      const timeout = setTimeout(resolve, 5000);
      registration.addEventListener("updatefound", () => { clearTimeout(timeout); resolve(); }, {once: true});
    });
    worker = [registration.installing, registration.waiting, registration.active].find((candidate) => candidate?.scriptURL === offlineWorkerURL);
  }
  if (!worker) return;
  if (worker.state !== "activated" && worker.state !== "redundant") await new Promise((resolve) => {
    const timeout = setTimeout(resolve, 5000);
    const settled = () => {
      if (worker.state !== "activated" && worker.state !== "redundant") return;
      clearTimeout(timeout);
      worker.removeEventListener("statechange", settled);
      resolve();
    };
    worker.addEventListener("statechange", settled);
    settled();
  });
  if (worker.state !== "activated" || navigator.serviceWorker.controller?.scriptURL !== offlineWorkerURL) await new Promise((resolve) => {
    const timeout = setTimeout(resolve, 5000);
    navigator.serviceWorker.addEventListener("controllerchange", () => { clearTimeout(timeout); resolve(); }, {once: true});
  });
  return currentOfflineServiceWorker();
};
const offlineServiceWorker = "serviceWorker" in navigator && window.isSecureContext
  ? currentOfflineServiceWorker().then((registration) => registration || navigator.serviceWorker.register(offlineWorkerPath).then(activateOfflineServiceWorker)).catch(currentOfflineServiceWorker)
  : Promise.resolve(undefined);
const offlineContext = () => document.querySelector("#downloads, [data-offline-library]")?.dataset || {};
const offlineMessage = (name, fallback) => offlineContext()[name] || fallback;
const offlineWorkerError = () => offlineMessage("offlineWorkerRequired", "Offline playback is not ready in this browser. Reconnect to the Server and reload Kinosail.");
const offlineRemovalError = () => offlineMessage("offlineRemovalError", "Could not remove this device’s offline data. Try again.");
const requireOfflineServiceWorker = async () => {
  const registration = await offlineServiceWorker;
  if (!registration || !isExactOfflineWorker(navigator.serviceWorker.controller)) throw new Error(offlineWorkerError());
  return registration;
};
const currentOfflineProfile = () => document.body.dataset.viewerProfile || document.querySelector("#downloads")?.dataset.viewerProfile || document.querySelector("[data-nav-profile]")?.dataset.navProfile || "";
const playerStorageValue = (key, value) => {
  try { if (value !== undefined) localStorage.setItem(key, value); return localStorage.getItem(key) || ""; } catch (_) { return ""; }
};
const activeOfflineProfile = () => window.kinosailOfflineIdentity?.current() ?? playerStorageValue("kinosail.offline-profile");
const offlineJobLockName = (id) => `kinosail-offline:${id}`;
const offlineTransferID = /^[0-9a-f]{32}$/;
const offlineTransferIDOf = (job) => offlineTransferID.test(job?.transferID || "") ? job.transferID : "";
const offlineSourceTransfers = new Map();
const offlineTransfers = new Map();
const offlineNow = () => performance.timeOrigin + performance.now();
const cancelOfflineTransfer = (request) => {
  if (!/^[0-9a-f]{16}$/.test(request?.jobID || "") || !Number.isFinite(request.requestedAt) || request.requestedAt < 0 || request.requestedAt > offlineNow() + 1000) return;
  const owner = offlineTransfers.get(request.jobID);
  if (owner && (request.transferID ? owner.transferID === request.transferID : owner.startedAt <= request.requestedAt)) owner.controller.abort();
};
const offlineDelay = (delay, signal) => new Promise((resolve, reject) => {
  signal?.throwIfAborted();
  const abort = () => { clearTimeout(timer); reject(signal.reason); };
  const timer = setTimeout(() => { signal?.removeEventListener("abort", abort); resolve(); }, delay);
  signal?.addEventListener("abort", abort, {once: true});
});
const withOfflineJobLock = async (id, action, transfer = false, signal) => {
  if (!navigator.locks?.request) throw new Error(transfer ? offlineMessage("offlineStorageUnsupported", "This browser cannot store offline media safely") : offlineRemovalError());
  return navigator.locks.request(offlineJobLockName(id), {mode: "exclusive", ...(signal ? {signal} : {})}, action);
};

const withOfflineTransferSlot = async (action, signal) => {
  const names = ["kinosail-offline-slot:0", "kinosail-offline-slot:1"];
  for (const name of names) {
    signal?.throwIfAborted();
    const result = await navigator.locks.request(name, {ifAvailable: true}, async (lock) => lock ? {value: await action()} : undefined);
    if (result) return result.value;
  }
  let winner;
  const controllers = names.map(() => new AbortController());
  const attempts = names.map((name, index) => navigator.locks.request(name, {signal: signal ? AbortSignal.any([signal, controllers[index].signal]) : controllers[index].signal}, async () => {
    signal?.throwIfAborted();
    if (winner !== undefined) return;
    winner = index;
    controllers.forEach((controller, other) => { if (other !== index) controller.abort(); });
    return {value: await action()};
  }).catch((error) => { if (winner === undefined || winner === index) throw error; }));
  const results = await Promise.all(attempts);
  return results.find((result) => result)?.value;
};

let offlineDatabaseConnection;
const closeOfflineDatabase = () => {
  const connection = offlineDatabaseConnection;
  offlineDatabaseConnection = undefined;
  connection?.then((database) => database.close()).catch(() => {});
};
async function openOfflineDatabase() {
  await requireOfflineServiceWorker();
  if (!offlineDatabaseConnection) {
    const connection = openOfflineDatabaseConnection().then((database) => {
      const reset = () => { if (offlineDatabaseConnection === connection) offlineDatabaseConnection = undefined; database.close(); };
      database.onversionchange = reset;
      database.onclose = reset;
      return database;
    }).catch((error) => { if (offlineDatabaseConnection === connection) offlineDatabaseConnection = undefined; throw error; });
    offlineDatabaseConnection = connection;
  }
  return offlineDatabaseConnection;
}

async function offlineRequest(store, mode, action) {
  const database = await openOfflineDatabase();
  return new Promise((resolve, reject) => {
    const transaction = database.transaction(store, mode, mode === "readwrite" ? {durability: "strict"} : undefined);
    let result;
    let request;
    transaction.oncomplete = () => resolve(result);
    transaction.onabort = () => reject(transaction.error || request?.error || new Error("Offline storage interrupted"));
    try { request = action(transaction.objectStore(store)); }
    catch (error) { transaction.abort(); reject(error); return; }
    request.onsuccess = () => { result = request.result; };
  });
}

const openExistingOfflineDatabase = () => new Promise((resolve, reject) => {
  const request = indexedDB.open(offlineDatabase);
  let missing = false;
  request.onupgradeneeded = () => { missing = true; request.transaction.abort(); };
  request.onsuccess = () => resolve(request.result);
  request.onerror = () => missing && request.error?.name === "AbortError" ? resolve(undefined) : reject(request.error);
});
const readExistingOfflineJob = (database, id) => new Promise((resolve, reject) => {
  const request = database.transaction("jobs", "readonly").objectStore("jobs").get(id);
  request.onsuccess = () => resolve(request.result);
  request.onerror = () => reject(request.error);
});

const getOfflineJob = (id) => offlineRequest("jobs", "readonly", (store) => store.get(id));
const getOfflineJobs = () => offlineRequest("jobs", "readonly", (store) => store.getAll());
const getOfflineChunk = (id) => offlineRequest("chunks", "readonly", (store) => store.get(id));
const saveOfflineJob = (job) => offlineRequest("jobs", "readwrite", (store) => store.put(job));
const saveOfflineChunk = (chunk) => offlineRequest("chunks", "readwrite", (store) => store.put(chunk));

async function getExistingOfflineJob(id) {
  const database = await openExistingOfflineDatabase();
  if (!database) return;
  try {
    return await readExistingOfflineJob(database, id);
  } finally { database.close(); }
}

async function removeOfflineJob(id) {
  const database = await openExistingOfflineDatabase();
  const removeFile = async () => {
    if (!navigator.storage?.getDirectory) return;
    try { await (await navigator.storage.getDirectory()).removeEntry(id); }
    catch (error) { if (error?.name !== "NotFoundError") throw error; }
  };
  if (!database) return removeFile();
  try {
    const job = await readExistingOfflineJob(database, id);
    if (!job || job.storage === "opfs") await removeFile();
    await new Promise((resolve, reject) => {
      const transaction = database.transaction(["jobs", "chunks"], "readwrite");
      const jobs = transaction.objectStore("jobs");
      const chunks = transaction.objectStore("chunks");
      jobs.delete(id);
      if (chunks.indexNames.contains("jobID")) chunks.index("jobID").getAllKeys(id).onsuccess = ({target}) => {
        for (const chunkID of target.result) chunks.delete(chunkID);
      };
      else chunks.openCursor().onsuccess = ({target}) => {
        const cursor = target.result;
        if (!cursor) return;
        if (cursor.value?.jobID === id) cursor.delete();
        cursor.continue();
      };
      transaction.oncomplete = resolve;
      transaction.onerror = () => reject(transaction.error);
      transaction.onabort = () => reject(transaction.error);
    });
  } finally { database.close(); }
}

async function removeOfflineJobSafely(id, explicit = false, afterRemove) {
  if (!/^[0-9a-f]{16}$/.test(id)) throw new Error(offlineRemovalError());
  const sourceTransferID = explicit ? undefined : offlineSourceTransfers.get(id);
  const observed = sourceTransferID === undefined ? await getExistingOfflineJob(id) : {transferID: sourceTransferID};
  const request = {type: "cancel", jobID: id, requestedAt: offlineNow(), transferID: sourceTransferID};
  cancelOfflineTransfer(request);
  offlineChannel?.postMessage(request);
  try {
    return await withOfflineJobLock(id, async () => {
      const current = await getExistingOfflineJob(id);
      const transferID = offlineTransferIDOf(current);
      // A removal from an old playback source must never delete its replacement.
      if (current && (sourceTransferID !== undefined ? transferID !== sourceTransferID :
        Number.isFinite(current.transferStartedAt) ? current.transferStartedAt > request.requestedAt : transferID !== offlineTransferIDOf(observed))) return false;
      await removeOfflineJob(id);
      await afterRemove?.();
      return true;
    });
  } finally { offlineSourceTransfers.delete(id); }
}

window.addEventListener("kinosail:offline-profile", () => {
  for (const transfer of offlineTransfers.values()) transfer.controller.abort();
  for (const media of document.querySelectorAll('[data-offline-library] video, [data-offline-library] audio')) {
    media.pause(); media.removeAttribute("src"); media.load();
  }
  renderOfflineLibrary().catch(() => {});
});
function resolveOfflineWorkerRequest(pending, data) {
  const request = pending.get(data.id);
  if (!request) return;
  if (request.timer !== undefined) clearTimeout(request.timer);
  pending.delete(data.id);
  if (data.error) request.reject(new Error(data.error));
  else request.resolve(data.value);
}


async function offlineDigest(data) {
  const digest = new Uint8Array(await crypto.subtle.digest("SHA-256", data));
  return [...digest].map((byte) => byte.toString(16).padStart(2, "0")).join("");
}

function contentDigest(value) {
  const match = value?.match(/^sha-256=:([A-Za-z0-9+/]{43}=):$/);
  if (!match) return "";
  return [...Uint8Array.from(atob(match[1]), (character) => character.charCodeAt(0))].map((byte) => byte.toString(16).padStart(2, "0")).join("");
}

function sha256WorkerScope() {
const sha256Constants = new Uint32Array([
  0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
  0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
  0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
  0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
  0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
  0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
  0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
  0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2,
]);
const rotateRight = (value, count) => value >>> count | value << 32 - count;

class StreamingSHA256 {
  constructor() {
    this.state = new Uint32Array([0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a, 0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19]);
    this.buffer = new Uint8Array(64);
    this.bufferLength = 0;
    this.bytes = 0;
    this.words = new Uint32Array(64);
  }

  update(value) {
    const data = value instanceof Uint8Array ? value : new Uint8Array(value);
    this.bytes += data.byteLength;
    let offset = 0;
    while (offset < data.byteLength) {
      const length = Math.min(64 - this.bufferLength, data.byteLength - offset);
      this.buffer.set(data.subarray(offset, offset + length), this.bufferLength);
      this.bufferLength += length;
      offset += length;
      if (this.bufferLength === 64) { this.compress(this.buffer); this.bufferLength = 0; }
    }
    return this;
  }

  compress(block) {
    const words = this.words;
    const view = new DataView(block.buffer, block.byteOffset, block.byteLength);
    for (let index = 0; index < 16; index++) words[index] = view.getUint32(index * 4);
    for (let index = 16; index < 64; index++) {
      const before = words[index - 15];
      const recent = words[index - 2];
      const small0 = rotateRight(before, 7) ^ rotateRight(before, 18) ^ before >>> 3;
      const small1 = rotateRight(recent, 17) ^ rotateRight(recent, 19) ^ recent >>> 10;
      words[index] = words[index - 16] + small0 + words[index - 7] + small1;
    }
    let [a, b, c, d, e, f, g, h] = this.state;
    for (let index = 0; index < 64; index++) {
      const large1 = rotateRight(e, 6) ^ rotateRight(e, 11) ^ rotateRight(e, 25);
      const choice = e & f ^ ~e & g;
      const first = h + large1 + choice + sha256Constants[index] + words[index];
      const large0 = rotateRight(a, 2) ^ rotateRight(a, 13) ^ rotateRight(a, 22);
      const majority = a & b ^ a & c ^ b & c;
      const second = large0 + majority;
      h = g; g = f; f = e; e = d + first; d = c; c = b; b = a; a = first + second;
    }
    for (const [index, value] of [a, b, c, d, e, f, g, h].entries()) this.state[index] += value;
  }

  hex() {
    const final = new Uint8Array(this.bufferLength < 56 ? 64 : 128);
    final.set(this.buffer.subarray(0, this.bufferLength));
    final[this.bufferLength] = 0x80;
    const view = new DataView(final.buffer);
    view.setUint32(final.byteLength - 8, Math.floor(this.bytes / 0x20000000));
    view.setUint32(final.byteLength - 4, this.bytes << 3);
    for (let offset = 0; offset < final.byteLength; offset += 64) this.compress(final.subarray(offset, offset + 64));
    return [...this.state].map((word) => word.toString(16).padStart(8, "0")).join("");
  }
}

let digest = new StreamingSHA256();
self.onmessage = ({data}) => {
  try {
    if (data.type === "update") digest.update(data.value);
    const value = data.type === "hex" ? digest.hex() : undefined;
    self.postMessage({id: data.id, value});
  } catch (error) { self.postMessage({id: data.id, error: error instanceof Error ? error.message : "SHA-256 failed"}); }
};
}

function streamingOfflineDigest() {
  const source = `(${sha256WorkerScope.toString()})()`;
  const url = URL.createObjectURL(new Blob([source], {type: "text/javascript"}));
  const worker = new Worker(url);
  let revoked = false;
  const revoke = () => { if (!revoked) URL.revokeObjectURL(url); revoked = true; };
  let nextID = 0;
  const pending = new Map();
  const fail = (error) => {
    for (const {reject} of pending.values()) reject(error);
    pending.clear();
  };
  worker.onerror = (event) => { revoke(); fail(new Error(event.message || "SHA-256 failed")); };
  worker.onmessage = ({data}) => {
    revoke();
    resolveOfflineWorkerRequest(pending, data);
  };
  const request = (type, value) => new Promise((resolve, reject) => {
    const id = nextID++;
    pending.set(id, {resolve, reject});
    worker.postMessage({id, type, value}, value ? [value] : []);
  });
  return {update: (data) => request("update", data), hex: () => request("hex"), close: () => { revoke(); fail(new Error("SHA-256 closed")); worker.terminate(); }};
}
// One worker owns the file handle for a transfer. Flush each verified block
// before its IndexedDB metadata can make it visible to offline playback.
function offlineStorageWorkerScope() {
  let handle, size;
  const operations = new Set(["read", "write", "truncate", "close"]);
  self.onmessage = async ({data: message}) => {
    const {id, type, value} = message;
    try {
      let result;
      if (type === "open") {
        if (handle || !/^[0-9a-f]{16}$/.test(value?.jobID || "") || !Number.isSafeInteger(value.size) || value.size <= 0 || value.size > 128 * 1024 ** 3) throw new Error("Invalid offline file");
        if (typeof FileSystemFileHandle === "undefined" || !FileSystemFileHandle.prototype.createSyncAccessHandle) { self.postMessage({id, value: false}); return; }
        size = value.size;
        const file = await (await navigator.storage.getDirectory()).getFileHandle(value.jobID, {create: true});
        handle = await file.createSyncAccessHandle();
        result = true;
      } else {
        if (!handle || !operations.has(type)) throw new Error("Offline writer unavailable");
        if (type === "close") { handle.flush(); handle.close(); handle = undefined; }
        else if (type === "truncate") { handle.truncate(size); handle.flush(); }
        else {
          const length = type === "write" ? value?.data?.byteLength : value?.length;
          if (!Number.isSafeInteger(value?.offset) || value.offset < 0 || !Number.isSafeInteger(length) || length <= 0 || length > 8 * 1024 ** 2 || value.offset + length > size) throw new Error("Invalid offline range");
          if (type === "read") {
            const bytes = new Uint8Array(length);
            result = bytes.buffer.slice(0, handle.read(bytes, {at: value.offset}));
          } else {
            if (!(value.data instanceof ArrayBuffer) || handle.write(new Uint8Array(value.data), {at: value.offset}) !== length) throw new Error("Offline write incomplete");
            handle.flush();
          }
        }
      }
      self.postMessage({id, value: result}, result instanceof ArrayBuffer ? [result] : []);
    } catch (error) { self.postMessage({id, error: error instanceof Error ? error.message : "Offline storage failed"}); }
  };
}

async function openOfflineWriter(jobID, size) {
  if (!navigator.storage?.getDirectory || !("Worker" in window)) return;
  const url = URL.createObjectURL(new Blob([`(${offlineStorageWorkerScope.toString()})()`], {type: "text/javascript"}));
  const worker = new Worker(url);
  let nextID = 0, failed;
  const pending = new Map();
  const stop = (error) => {
    failed = error;
    for (const request of pending.values()) { clearTimeout(request.timer); request.reject(error); }
    pending.clear();
    worker.terminate();
    URL.revokeObjectURL(url);
  };
  worker.onerror = () => stop(new Error("Offline storage worker failed"));
  worker.onmessage = ({data}) => {
    resolveOfflineWorkerRequest(pending, data);
  };
  const request = (type, value) => new Promise((resolve, reject) => {
    if (failed) { reject(failed); return; }
    const id = nextID++;
    const timer = setTimeout(() => stop(new Error("Offline storage stopped responding")), 30000);
    pending.set(id, {resolve, reject, timer});
    // Clone writes: the incremental digest worker subsequently takes ownership.
    worker.postMessage({id, type, value});
  });
  try {
    if (!await request("open", {jobID, size})) { stop(new Error("Offline writer unsupported")); return; }
  } catch (error) { stop(error); throw error; }
  return {
    read: (offset, length) => request("read", {offset, length}),
    write: (offset, data) => request("write", {offset, data}),
    truncate: () => request("truncate"),
    close: async () => { try { if (!failed) await request("close"); } finally { stop(new Error("Offline writer closed")); } },
  };
}
const offlineItemID = /^[0-9a-f]{16}$/;
const offlineProfileID = /^[A-Za-z0-9_-]{1,256}$/;
const offlineExtension = /^(?:|\.[A-Za-z0-9]{1,15})$/;
const offlineQualities = new Set(["original", "compatible", "1080p", "720p", "480p", "audio"]);
function validOfflineManifest(job, expected) {
  return job && Object.getPrototypeOf(job) === Object.prototype &&
    /^[0-9a-f]{16}$/.test(job.id) && job.id === expected.jobID &&
    typeof job.itemId === "string" && offlineItemID.test(job.itemId) && job.itemId === expected.itemID &&
    typeof job.profileId === "string" && offlineProfileID.test(job.profileId) && job.profileId === expected.profileID &&
    typeof job.title === "string" && job.title.length > 0 && job.title.length <= 512 && job.title === expected.title &&
    typeof job.quality === "string" && offlineQualities.has(job.quality) && job.quality === expected.quality &&
    job.state === "ready" && job.readyOffline === true &&
    typeof job.extension === "string" && offlineExtension.test(job.extension) &&
    /^[0-9a-f]{64}$/.test(job.sha256) && Number.isSafeInteger(job.size) && job.size > 0 && job.size <= chunkSize * 16384;
}

const offlineStatuses = new Map();
function showOfflineStatus(jobID, detail) {
  if (!/^[0-9a-f]{16}$/.test(jobID || "")) return;
  offlineStatuses.set(jobID, detail);
  if (offlineStatuses.size > 50) offlineStatuses.delete(offlineStatuses.keys().next().value);
  document.dispatchEvent(new CustomEvent("kinosail:offline-download", {detail: {jobID, ...detail}}));
  const article = document.querySelector(`[data-download-job="${CSS.escape(jobID)}"]`);
  const status = article?.querySelector("[data-download-device-status]");
  const play = article?.querySelector("[data-download-play]");
  if (play) play.hidden = detail.state !== "ready";
  if (!status) return;
  status.textContent = detail.state === "ready"
    ? detail.playbackVerified ? offlineMessage("offlineReady", "Ready offline on this device") : offlineMessage("offlineVerified", "Saved and verified. Play to check compatibility.")
    : detail.error || `${detail.percent || 0}% ${offlineMessage("offlineStored", "stored on this device")}${detail.estimate ? ` · ${detail.estimate}` : ""}`;
  if (detail.state === "transferring") status.textContent += ` · ${offlineMessage("offlineKeepOpen", "Keep this page open")}`;
}

function notifyOffline(jobID, detail) {
  showOfflineStatus(jobID, detail);
  offlineChannel?.postMessage({jobID, detail});
}

async function offlineFile(jobID) {
  return (await navigator.storage.getDirectory()).getFileHandle(jobID, {create: true});
}

async function readOfflineFile(jobID, offset, length) {
  const file = await (await (await navigator.storage.getDirectory()).getFileHandle(jobID)).getFile();
  return file.slice(offset, offset + length).arrayBuffer();
}

async function offlineFileSize(jobID) {
  try { return (await (await (await navigator.storage.getDirectory()).getFileHandle(jobID)).getFile()).size; }
  catch (error) { if (error?.name === "NotFoundError") return 0; throw error; }
}

async function writeOfflineFile(jobID, offset, data) {
  const writable = await (await offlineFile(jobID)).createWritable({keepExistingData: true});
  try { await writable.write({type: "write", position: offset, data}); await writable.close(); }
  catch (error) { await writable.abort().catch(() => {}); throw error; }
}

async function truncateOfflineFile(jobID, size) {
  const writable = await (await offlineFile(jobID)).createWritable({keepExistingData: true});
  try { await writable.truncate(size); await writable.close(); }
  catch (error) { await writable.abort().catch(() => {}); throw error; }
}

async function ensureOfflineCapacity(size, jobID) {
  const estimate = await navigator.storage?.estimate?.();
  const locks = await navigator.locks.query();
  const held = new Set(locks.held.map((lock) => lock.name));
  const reserved = (await getOfflineJobs()).reduce((total, job) => total + (job.id !== jobID && job.state === "transferring" && held.has(offlineJobLockName(job.id)) && Number.isSafeInteger(job.reservedBytes) && job.reservedBytes > 0 && job.reservedBytes <= chunkSize * 16384 ? job.reservedBytes : 0), 0);
  if (estimate?.quota && estimate.usage + size + reserved > estimate.quota) throw new Error(offlineMessage("offlineCapacityError", "This device does not have enough storage for this download"));
}

async function validStoredOfflineChunk(job, record, offset, length, writer) {
  const stored = await getOfflineChunk(`${job.id}:${offset}`);
  if (!stored || stored.jobID !== job.id || stored.offset !== offset || stored.length !== length || !/^[0-9a-f]{64}$/.test(stored.sha256)) return;
  const data = record.storage === "opfs" ? await (writer ? writer.read(offset, length) : readOfflineFile(job.id, offset, length)).catch(() => undefined) : stored.data;
  if (!data || data.byteLength !== length || await offlineDigest(data) !== stored.sha256) return;
  return data;
}

async function indexedDBOfflineAllocation(job, record) {
  if (record?.storage !== "indexeddb") return 0;
  let bytes = 0;
  for (let offset = 0; offset < job.size; offset += chunkSize) {
    const stored = await getOfflineChunk(`${job.id}:${offset}`);
    const length = stored?.data?.byteLength;
    if (Number.isSafeInteger(length) && length > 0) bytes = Math.min(job.size, bytes + length);
  }
  return bytes;
}

// Retry only transport failures and temporary server responses. Each attempt is
// bounded in memory and has an idle deadline, including while reading the body.
async function fetchOfflineChunk(job, offset, length, signal) {
  for (let attempt = 0; ; attempt++) {
    signal?.throwIfAborted();
    const controller = new AbortController();
    const abort = () => controller.abort();
    signal?.addEventListener("abort", abort, {once: true});
    let timeout;
    const touch = () => { clearTimeout(timeout); timeout = setTimeout(() => controller.abort(), 30000); };
    let response;
    let reader;
    try {
      touch();
      response = await fetch(`/api/v1/downloads/${encodeURIComponent(job.id)}/file`, {
        headers: {Range: `bytes=${offset}-${offset + length - 1}`},
        credentials: "same-origin", cache: "no-store", redirect: "error", signal: controller.signal,
      });
      if ([408, 429, 500, 502, 503, 504].includes(response.status)) throw new TypeError("Temporary download failure");
      const range = response.headers.get("Content-Range")?.match(/^bytes (\d+)-(\d+)\/(\d+)$/);
      if (response.status !== 206 || !range || Number(range[1]) !== offset || Number(range[2]) !== offset + length - 1 || Number(range[3]) !== job.size || !response.body) throw new Error(offlineMessage("offlineVerificationError", "The download could not be verified"));
      const data = new Uint8Array(length);
      reader = response.body.getReader();
      let received = 0;
      for (;;) {
        const {done, value} = await reader.read();
        if (done) break;
        if (received + value.byteLength > length) throw new Error(offlineMessage("offlineVerificationError", "The download could not be verified"));
        data.set(value, received);
        received += value.byteLength;
        if (value.byteLength) touch();
      }
      if (received !== length) throw new TypeError("Download interrupted");
      if (await offlineDigest(data.buffer) !== contentDigest(response.headers.get("Content-Digest"))) throw new Error(offlineMessage("offlineVerificationError", "The download could not be verified"));
      signal?.throwIfAborted();
      return data.buffer;
    } catch (error) {
      signal?.throwIfAborted();
      if (attempt >= 5 || !(error instanceof TypeError || controller.signal.aborted)) throw error;
    } finally {
      clearTimeout(timeout);
      signal?.removeEventListener("abort", abort);
      controller.abort();
      await (reader ? reader.cancel() : response?.body?.cancel())?.catch(() => {});
    }
    notifyOffline(job.id, {state: "waiting", error: offlineMessage("offlineRetrying", "Connection interrupted. Retrying automatically…")});
    const retryAfter = response?.headers.get("Retry-After");
    const serverDelay = /^\d{1,6}$/.test(retryAfter || "") ? Number(retryAfter) * 1000 : Date.parse(retryAfter || "") - Date.now();
    if (serverDelay > 60000) throw new Error(offlineMessage("offlineBusy", "The Server is busy. Your progress is saved; try again later."));
    const delay = Math.min(60000, Math.max(1000 * 2 ** attempt + Math.random() * 500, Number.isFinite(serverDelay) ? serverDelay : 0));
    await offlineDelay(delay, signal);
  }
}

async function transferOfflineJob(job, expected, owner) {
  if (!hasOfflineStorage || !("Worker" in window)) throw new Error(offlineMessage("offlineStorageUnsupported", "This browser cannot store offline media safely"));
  if (!validOfflineManifest(job, expected)) throw new Error(offlineMessage("offlineVerificationError", "The download could not be verified"));
  const controller = new AbortController();
  const signal = controller.signal;
  const abort = () => controller.abort();
  owner?.controller.signal.throwIfAborted();
  owner?.controller.signal.addEventListener("abort", abort, {once: true});
  let record, writer, digest, pending, admitted = false;
  try {
    await requireOfflineServiceWorker();
    signal.throwIfAborted();
    record = await getOfflineJob(job.id);
    if (record && (record.integrityVersion !== offlineIntegrityVersion || record.sha256 !== job.sha256 || record.size !== job.size || record.itemID !== job.itemId || record.profileID !== job.profileId || !["opfs", "indexeddb"].includes(record.storage))) {
      await removeOfflineJob(job.id);
      record = undefined;
    }
    const previousTransferID = offlineTransferIDOf(record);
    const requiredCapacity = record?.storage === "opfs"
      ? Math.max(0, job.size - await offlineFileSize(job.id))
      : Math.max(0, job.size - await indexedDBOfflineAllocation(job, record));
    signal.throwIfAborted();
    if (!record || record.storage === "opfs") {
      try { writer = await openOfflineWriter(job.id, job.size); }
      catch (error) { if (record) throw error; }
    }
    record = record || {id: job.id, integrityVersion: offlineIntegrityVersion, profileID: job.profileId, itemID: job.itemId, title: job.title, quality: job.quality, extension: job.extension || "", sha256: job.sha256, size: job.size, storage: writer ? "opfs" : "indexeddb"};
    signal.throwIfAborted();
    if (!record.progressBaseline) record.progressBaseline = await downloadProgressBaseline(job.itemId, job.profileId, signal);
    record.extension = job.extension || record.extension || "";
    record.transferID = owner?.transferID || [...crypto.getRandomValues(new Uint8Array(16))].map((byte) => byte.toString(16).padStart(2, "0")).join("");
    record.transferStartedAt = owner?.startedAt || offlineNow();
    record.state = "transferring";
    record.readyOffline = false;
    delete record.playbackAgent;
    record.error = "";
    record.bytes = 0;
    record.reservedBytes = requiredCapacity;
    signal.throwIfAborted();
    await navigator.locks.request("kinosail-offline-capacity", {signal}, async () => {
      signal.throwIfAborted();
      await ensureOfflineCapacity(requiredCapacity, job.id);
      signal.throwIfAborted();
      await beginOfflineTransfer(record, previousTransferID);
      admitted = true;
    });
    digest = streamingOfflineDigest();
    let networkBytes = 0, networkStart = 0;
    const prepare = async (offset) => {
      signal.throwIfAborted();
      const length = Math.min(chunkSize, job.size - offset);
      let data = await validStoredOfflineChunk(job, record, offset, length, writer);
      const stored = Boolean(data);
      if (!stored) {
        if (!networkStart) networkStart = performance.now();
        data = await fetchOfflineChunk(job, offset, length, signal);
        networkBytes += length;
      }
      return {data, stored, length, sha256: stored ? "" : await offlineDigest(data)};
    };
    const prefetch = (offset) => { const task = prepare(offset); task.catch(() => {}); return task; };
    pending = prefetch(0);
    for (let offset = 0; offset < job.size; offset += chunkSize) {
      const {data, stored, length, sha256} = await pending;
      signal.throwIfAborted();
      pending = offset + length < job.size ? prefetch(offset + length) : undefined;
      if (!stored) {
        const chunk = {id: `${job.id}:${offset}`, jobID: job.id, offset, length, sha256};
        if (record.storage === "opfs") {
          if (writer) await writer.write(offset, data);
          else await writeOfflineFile(job.id, offset, data);
          signal.throwIfAborted();
          await saveOfflineChunk(chunk);
        } else await saveOfflineChunk({...chunk, data});
        record.reservedBytes = Math.max(0, record.reservedBytes - length);
      }
      await digest.update(data);
      signal.throwIfAborted();
      record.bytes += length;
      await saveOfflineJob(record);
      const elapsed = performance.now() - networkStart;
      const speed = networkBytes * 1000 / elapsed;
      const minutes = Math.max(1, Math.ceil((job.size - record.bytes) / speed / 60));
      const estimate = networkBytes > 0 && elapsed >= 2000 && record.bytes < job.size
        ? `${(speed / 1024 ** 2).toFixed(1)} MB/s · ~${minutes} min` : "";
      notifyOffline(job.id, {state: "transferring", percent: Math.min(99, Math.floor(record.bytes / job.size * 100)), estimate});
    }
    if (record.storage === "opfs") {
      if (writer) { await writer.truncate(); await writer.close(); writer = undefined; }
      else await truncateOfflineFile(job.id, job.size);
    }
    signal.throwIfAborted();
    if (await digest.hex() !== job.sha256) {
      record.integrityVersion = 0;
      await removeOfflineJob(job.id).catch(() => {});
      throw new Error(offlineMessage("offlineVerificationError", "The download could not be verified"));
    }
    signal.throwIfAborted();
    delete record.reservedBytes;
    record.state = "ready";
    record.readyOffline = true;
    await saveOfflineJob(record);
    notifyOffline(job.id, {state: "ready"});
    return record;
  } catch (error) {
    if (record && admitted) {
      record.state = "needs_attention";
      record.readyOffline = false;
      record.error = signal.aborted ? offlineMessage("offlinePaused", "Download interrupted. Resume to continue where it stopped.") : error instanceof Error ? error.message : offlineMessage("offlineVerificationError", "The download could not be verified");
      await saveOfflineJob(record);
      notifyOffline(job.id, {state: record.state, error: record.error});
    }
    throw error;
  } finally {
    controller.abort();
    owner?.controller.signal.removeEventListener("abort", abort);
    await pending?.catch(() => {});
    digest?.close();
    await writer?.close();
  }
}
// Progress lives with the verified, profile-owned download. Never create a job
// while saving progress: removal or a replacement transfer wins the race.
function offlineProgress(value, required = false) {
  if (!value || typeof value !== "object" || Array.isArray(value)) throw new Error("Saved progress is invalid.");
  if (Object.keys(value).sort().join(",") !== "revision,seconds,session,watched") throw new Error("Saved progress is invalid.");
  const {seconds, watched, session, revision} = value;
  if (!Number.isFinite(seconds) || seconds < 0 || seconds > 31536000 || typeof watched !== "boolean" || typeof session !== "string" || session.length > 128 || /[\x00-\x1f\x7f]/.test(session) || !Number.isSafeInteger(revision) || revision < 0 || (required && (!session || !revision))) throw new Error("Saved progress is invalid.");
  return {seconds, watched, session, revision};
}
function offlineServerProgress(value) {
  if (!value || typeof value !== "object" || Array.isArray(value) || Object.keys(value).some(key => !["seconds", "watched", "session", "revision", "updated", "dismissed", "readerOffset", "readerPage"].includes(key))) throw new Error("Progress response is invalid.");
  return offlineProgress({seconds: value.seconds ?? 0, watched: value.watched ?? false, session: value.session ?? "", revision: value.revision ?? 0});
}
function validOfflineProgressJob(job) {
  return job && /^[0-9a-f]{16}$/.test(job.id || "") && offlineItemID.test(job.itemID || "") && offlineProfileID.test(job.profileID || "") && /^[0-9a-f]{64}$/.test(job.sha256 || "") && Boolean(offlineTransferIDOf(job));
}
const offlineProgressMatches = (left, right) => left?.profileID === right.profileID && left.itemID === right.itemID && left.sha256 === right.sha256 && offlineTransferIDOf(left) && offlineTransferIDOf(left) === offlineTransferIDOf(right) && left.state === "ready" && left.readyOffline;
async function updateOfflineProgress(job, change) {
  if (!offlineItemID.test(job.itemID || "") || !offlineProfileID.test(job.profileID || "") || !/^[0-9a-f]{16}$/.test(job.id || "") || activeOfflineProfile() !== job.profileID) throw new Error("Open this Viewer Profile to save progress.");
  const database = await openOfflineDatabase();
  return new Promise((resolve, reject) => {
    const transaction = database.transaction("jobs", "readwrite", {durability: "strict"}), store = transaction.objectStore("jobs");
    let result;
    store.get(job.id).onsuccess = ({target}) => {
      const current = target.result;
      if (!offlineProgressMatches(current, job)) { transaction.abort(); return; }
      try { result = change(current); store.put(current); } catch (_) { transaction.abort(); }
    };
    transaction.oncomplete = () => resolve(result);
    transaction.onabort = () => reject(new Error("Could not save offline progress. Return to Downloads and try again."));
  });
}
async function beginOfflineTransfer(record, previousTransferID) {
  const database = await openOfflineDatabase();
  return new Promise((resolve, reject) => {
    const transaction = database.transaction("jobs", "readwrite", {durability: "strict"});
    const store = transaction.objectStore("jobs");
    store.get(record.id).onsuccess = ({target}) => {
      const current = target.result;
      if (current && (offlineTransferIDOf(current) !== previousTransferID || current.profileID !== record.profileID || current.itemID !== record.itemID || current.sha256 !== record.sha256)) { transaction.abort(); return; }
      try {
        if (current) for (const key of ["progressBaseline", "localProgress", "pendingProgress"]) {
          if (current[key]) record[key] = offlineProgress(current[key], key !== "progressBaseline");
          else if (key !== "progressBaseline") delete record[key];
        }
        store.put(record);
      } catch (_) { transaction.abort(); }
    };
    transaction.oncomplete = resolve;
    transaction.onabort = () => reject(new Error("Download changed. Refresh Downloads and try again."));
  });
}

async function offlineProgressJSON(response) {
  if (!response.body) throw new Error("The Server response is empty.");
  const reader = response.body.getReader();
  const bytes = new Uint8Array(65536);
  let length = 0;
  try {
    for (;;) {
      const {done, value} = await reader.read();
      if (done) break;
      if (length + value.byteLength > bytes.length) throw new Error("The Server response is too large.");
      bytes.set(value, length);
      length += value.byteLength;
    }
    return JSON.parse(new TextDecoder("utf-8", {fatal: true}).decode(bytes.subarray(0, length)));
  } finally { await reader.cancel().catch(() => {}); }
}
async function downloadProgressBaseline(itemID, profileID, signal) {
  if (!offlineItemID.test(itemID || "") || !offlineProfileID.test(profileID || "")) throw new Error("Download identity is invalid.");
  const response = await fetch(`/api/v1/items/${encodeURIComponent(itemID)}`, {credentials: "same-origin", cache: "no-store", signal: signal ? AbortSignal.any([signal, AbortSignal.timeout(10000)]) : AbortSignal.timeout(10000)});
  if (!response.ok) throw new Error("Could not read progress before downloading. Try again.");
  const body = await offlineProgressJSON(response);
  if (body.profileId !== profileID || body.item?.id !== itemID) throw new Error("Download identity changed. Try again.");
  return offlineServerProgress(body.item.progress);
}
let syncingOfflineProgress = false;
async function syncOfflineProgress() {
  // Only an online, Server-rendered page supplies an authoritative profile and
  // CSRF token. The cached offline shell must never pick a sync identity.
  const profile = currentOfflineProfile(), csrf = document.querySelector('meta[name="kinosail-csrf"]')?.content;
  if (syncingOfflineProgress || !profile || !hasOfflineStorage || !navigator.locks?.request || !navigator.onLine) return;
  syncingOfflineProgress = true;
  try {
    const records = await getOfflineJobs();
    if (!Array.isArray(records) || records.length > 1000) return;
    const legacy = records.filter(job => validOfflineProgressJob(job) && job.profileID === profile && !job.progressBaseline && job.localProgress && job.state === "ready" && job.readyOffline).slice(0, 50);
    for (const job of legacy) {
      const baseline = await downloadProgressBaseline(job.itemID, job.profileID);
      await updateOfflineProgress(job, current => {
        if (current.progressBaseline) return;
        current.progressBaseline = baseline;
        const local = offlineProgress(current.localProgress, true);
        if (local.seconds > baseline.seconds) current.pendingProgress = local;
      });
    }
    const jobs = (await getOfflineJobs()).filter(job => validOfflineProgressJob(job) && job.profileID === profile && job.pendingProgress && job.state === "ready" && job.readyOffline).slice(0, 50);
    for (const job of jobs) {
      if (currentOfflineProfile() !== profile) break;
      let progress, expected;
      try { progress = offlineProgress(job.pendingProgress, true); expected = offlineProgress(job.progressBaseline); } catch (_) { continue; }
      const response = await fetch(`/api/v1/items/${encodeURIComponent(job.itemID)}/progress/sync`, {
        method: "PUT", credentials: "same-origin", signal: AbortSignal.timeout(10000),
        headers: {"Content-Type": "application/json", "X-Kinosail-Viewer-Profile": profile, ...(csrf ? {"X-Kinosail-CSRF": csrf} : {})},
        body: JSON.stringify({progress, expected, playbackToken: ""}),
      });
      if (![200, 409].includes(response.status)) continue;
      const body = await offlineProgressJSON(response), saved = offlineServerProgress(response.status === 409 ? body.progress : body);
      await updateOfflineProgress(job, current => {
        if (current.pendingProgress?.session !== progress.session || current.pendingProgress?.revision !== progress.revision) return;
        current.progressBaseline = saved;
        // Match native reconciliation: keep a further local position queued,
        // retrying against the fresh server baseline on the next pass.
        if (response.status === 409 && progress.seconds > saved.seconds) return;
        current.localProgress = saved;
        delete current.pendingProgress;
      });
    }
  } catch (_) { /* Local progress remains queued for the next connection. */ }
  finally { syncingOfflineProgress = false; }
}
function bindOfflineProgress(media, job, status, enabled = () => true) {
  let saved;
  try { saved = offlineProgress(job.localProgress ?? job.progressBaseline); }
  catch (_) { saved = {seconds: 0, watched: false, session: "", revision: 0}; }
  const session = `web-offline-${crypto.randomUUID()}`;
  let revision = 0, restored = false, lastSaved = 0, writes = Promise.resolve();
  const message = value => { if (status) status.textContent = value; };
  const restore = () => {
    if (!enabled()) return;
    if (!restored && !saved.watched && saved.seconds > 0 && saved.seconds < media.duration - 1) media.currentTime = saved.seconds;
    restored = true;
  };
  const save = (watched = false) => {
    if (!enabled() || !restored || !Number.isFinite(media.currentTime)) return Promise.resolve({ok: false});
    const progress = offlineProgress({seconds: media.currentTime, watched, session, revision: ++revision}, true);
    writes = writes.catch(() => {}).then(() => updateOfflineProgress(job, current => {
      current.localProgress = progress;
      // Old downloads resume locally until an online page captures their baseline.
      if (current.progressBaseline) {
        offlineProgress(current.progressBaseline);
        current.pendingProgress = progress;
      }
    }));
    return writes.then(() => {
      message(offlineMessage("offlineProgressSaved", "Progress saved on this device. Open Server downloads to sync."));
      return {ok: true};
    }, () => {
      message(offlineMessage("offlineProgressFailed", "Could not save progress. Return to Downloads and try again."));
      return {ok: false};
    });
  };
  const time = () => { if (performance.now() - lastSaved > 5000 && !media.paused) { lastSaved = performance.now(); void save(false); } };
  const pause = () => { if (!media.ended) void save(false); };
  const ended = () => { void save(true); };
  const leave = () => { if (enabled()) { media.pause(); void save(media.ended); } };
  const visibility = () => { if (document.visibilityState === "hidden") void save(media.ended); };
  const error = () => message(offlineMessage("offlinePlaybackFailed", "This browser could not play the saved file. Reconnect to the Server and choose a compatible download quality."));
  const listeners = [["loadedmetadata", restore], ["timeupdate", time], ["pause", pause], ["ended", ended], ["error", error]];
  for (const [name, listener] of listeners) media.addEventListener(name, listener);
  addEventListener("pagehide", leave, {once: true});
  document.addEventListener("visibilitychange", visibility);
  return {save, detach: () => {
    for (const [name, listener] of listeners) media.removeEventListener(name, listener);
    removeEventListener("pagehide", leave);
    document.removeEventListener("visibilitychange", visibility);
  }};
}
addEventListener("online", () => void syncOfflineProgress());
async function downloadOfflineJob(button) {
  const jobID = button.dataset.jobId;
  const expected = {jobID, itemID: button.dataset.itemId, profileID: currentOfflineProfile(), title: button.dataset.title, quality: button.dataset.quality};
  if (offlineTransfers.has(jobID)) return;
  const owner = {controller: new AbortController(), startedAt: offlineNow(), transferID: [...crypto.getRandomValues(new Uint8Array(16))].map((byte) => byte.toString(16).padStart(2, "0")).join("")};
  offlineTransfers.set(jobID, owner);
  button.disabled = true;
  try {
    if (!/^[0-9a-f]{16}$/.test(expected.jobID) || !offlineItemID.test(expected.itemID || "") || !offlineProfileID.test(expected.profileID) || !expected.title || expected.title.length > 512 || !offlineQualities.has(expected.quality)) throw new Error(offlineMessage("offlineVerificationError", "The download could not be verified"));
    const response = await fetch(`/api/v1/downloads/${encodeURIComponent(jobID)}`, {credentials: "same-origin", cache: "no-store", redirect: "error", signal: AbortSignal.any([owner.controller.signal, AbortSignal.timeout(15000)])});
    if (!response.ok) throw new Error(offlineMessage("offlineUnavailable", "The download is no longer available"));
    const job = await offlineProgressJSON(response);
    if (!validOfflineManifest(job, expected)) throw new Error(offlineMessage("offlineVerificationError", "The download could not be verified"));
    await requireOfflineServiceWorker();
    notifyOffline(jobID, {state: "waiting", error: offlineMessage("offlinePageRequired", "Keep this page open. Interrupted downloads can resume.")});
    await withOfflineJobLock(jobID, async () => {
      void navigator.storage?.persist?.().catch(() => {});
      return withOfflineTransferSlot(() => transferOfflineJob(job, expected, owner), owner.controller.signal);
    }, true, owner.controller.signal);
  } catch (error) {
    notifyOffline(jobID, {state: "needs_attention", error: owner.controller.signal.aborted ? offlineMessage("offlinePaused", "Download interrupted. Resume to continue where it stopped.") : error instanceof Error ? error.message : offlineMessage("offlineVerificationError", "The download could not be verified")});
  } finally {
    if (offlineTransfers.get(jobID) === owner) offlineTransfers.delete(jobID);
    button.disabled = false;
  }
}

function bindOfflineRemovalForms() {
  for (const form of document.querySelectorAll('form[action^="/offline-downloads/"][action$="/remove"]')) {
    if (form.dataset.bound) continue;
    form.dataset.bound = "true";
    form.addEventListener("submit", async (event) => {
      event.preventDefault();
      if (form.dataset.removing) return;
      form.dataset.removing = "true";
      const status = form.querySelector("[data-download-remove-status]");
      const controls = [...form.querySelectorAll('button:not([type]), button[type="submit"], input[type="submit"]')];
      for (const control of controls) control.disabled = true;
      try {
        const id = new URL(form.action).pathname.split("/").at(-2);
        if (!/^[0-9a-f]{16}$/.test(id || "")) throw new Error(offlineRemovalError());
        const removed = await removeOfflineJobSafely(id, true, async () => {
          const body = new URLSearchParams();
          for (const [name, value] of new FormData(form)) if (typeof value === "string") body.append(name, value);
          const response = await fetch(form.action, {method: "POST", body, credentials: "same-origin", headers: {"Content-Type": "application/x-www-form-urlencoded"}, signal: AbortSignal.timeout(15000)});
          if (!response.ok) throw new Error(offlineRemovalError());
          location.assign(response.url || "/offline-downloads");
        });
        if (!removed) throw new Error(offlineRemovalError());
      } catch (_) {
        form.dataset.removing = "";
        for (const control of controls) control.disabled = false;
        if (status) { status.hidden = false; status.textContent = offlineRemovalError(); }
      }
    });
  }
}

async function bindOfflineDownloads() {
  bindOfflineRemovalForms();
  const profile = currentOfflineProfile();
  if (profile) playerStorageValue("kinosail.offline-profile", profile);
  for (const button of document.querySelectorAll("[data-download-device]")) {
    if (button.dataset.bound) continue;
    button.dataset.bound = "true";
    button.addEventListener("click", () => downloadOfflineJob(button));
  }
  if (!hasOfflineStorage || !navigator.locks?.request) {
    for (const status of document.querySelectorAll("[data-download-device-status]")) status.textContent = offlineMessage("offlineStorageUnsupported", "This browser cannot store offline media safely");
    return;
  }
  try {
    const activeWorker = await offlineServiceWorker;
    for (const button of document.querySelectorAll("[data-download-device]")) {
      if (!activeWorker || !navigator.serviceWorker.controller) {
        const status = button.parentElement?.querySelector("[data-download-device-status]");
        if (status) status.textContent = offlineWorkerError();
        continue;
      }
      const live = offlineStatuses.get(button.dataset.jobId);
      if (live) showOfflineStatus(button.dataset.jobId, live);
      const record = await getOfflineJob(button.dataset.jobId);
      if (record?.profileID !== currentOfflineProfile()) continue;
      if (record.state === "ready" && record.readyOffline && record.sha256) notifyOffline(button.dataset.jobId, {state: "ready", playbackVerified: record.playbackAgent === navigator.userAgent.slice(0, 512)});
      else if (!offlineTransfers.has(record.id)) {
        const locks = await navigator.locks.query();
        if (!locks.held.some((lock) => lock.name === offlineJobLockName(record.id))) {
          button.textContent = offlineMessage("offlineResume", "Resume on this device");
          notifyOffline(record.id, {state: "needs_attention", error: record.error || offlineMessage("offlinePaused", "Download interrupted. Resume to continue where it stopped.")});
        }
      }
    }
  } catch (_) {
    for (const status of document.querySelectorAll("[data-download-device-status]")) status.textContent = offlineMessage("offlineStorageUnsupported", "This browser cannot store offline media safely");
  }
}

function bindOfflinePlaybackEvidence(media, record) {
  const source = new URL(`/offline-media/${encodeURIComponent(record.profileID)}/${encodeURIComponent(record.id)}`, location.href).href;
  const loaded = async () => {
    if (media.currentSrc !== source || media.readyState < HTMLMediaElement.HAVE_CURRENT_DATA) return;
    try {
      await updateOfflineProgress(record, (current) => { current.playbackAgent = navigator.userAgent.slice(0, 512); });
      notifyOffline(record.id, {state: "ready", playbackVerified: true});
    } catch (_) {}
  };
  media.addEventListener("loadeddata", loaded, {once: true});
  if (media.readyState >= HTMLMediaElement.HAVE_CURRENT_DATA) void loaded();
  return () => media.removeEventListener("loadeddata", loaded);
}

const offlinePlaybackBindings = new WeakMap();
window.KinosailOfflineMedia = {
  bindProgress: async (media, source, status) => {
    const profileID = activeOfflineProfile();
    const jobID = source.split("/").at(-1);
    const record = await getOfflineJob(jobID);
    if (!validOfflineProgressJob(record) || record.profileID !== profileID || source !== `/offline-media/${encodeURIComponent(profileID)}/${encodeURIComponent(record.id)}` || !record.readyOffline || record.state !== "ready" || offlineSourceTransfers.get(record.id) !== offlineTransferIDOf(record)) throw new Error("Offline download changed. Open Downloads and try again.");
    offlinePlaybackBindings.get(media)?.detach();
    const binding = bindOfflineProgress(media, record, status, () => media.dataset.offline === "true");
    const detachEvidence = bindOfflinePlaybackEvidence(media, record);
    const detachProgress = binding.detach;
    binding.detach = () => { detachEvidence(); detachProgress(); };
    offlinePlaybackBindings.set(media, binding);
    return () => { binding.detach(); offlinePlaybackBindings.delete(media); };
  },
  unbindProgress: (media) => { offlinePlaybackBindings.get(media)?.detach(); offlinePlaybackBindings.delete(media); },
  saveProgress: (media, watched) => offlinePlaybackBindings.get(media)?.save(watched) ?? Promise.resolve({ok: false}),
  source: async (itemID) => {
    if (!hasOfflineStorage || !itemID) return "";
    if (!await offlineServiceWorker || !navigator.serviceWorker.controller) return "";
    const profileID = activeOfflineProfile();
    const record = (await getOfflineJobs()).find((job) => job.profileID === profileID && job.itemID === itemID && job.state === "ready" && job.readyOffline);
    if (!record) return "";
    offlineSourceTransfers.set(record.id, offlineTransferIDOf(record));
    return `/offline-media/${encodeURIComponent(profileID)}/${encodeURIComponent(record.id)}`;
  },
  remove: removeOfflineJobSafely,
};

let downloadsEvents;
let downloadsPoll;
let refreshingDownloads = false;
let downloadsRefreshQueued = false;
const stopDownloadsPoll = () => { clearInterval(downloadsPoll); downloadsPoll = undefined; };
const refreshDownloads = async () => {
  const current = document.querySelector("#downloads");
  if (!current) return;
  if (refreshingDownloads) { downloadsRefreshQueued = true; return; }
  refreshingDownloads = true;
  try {
    const response = await fetch("/offline-downloads", {credentials: "same-origin", cache: "no-store"});
    if (!response.ok) return;
    const replacement = new DOMParser().parseFromString(await response.text(), "text/html").querySelector("#downloads");
    if (replacement && current.isConnected) {
      const active = document.activeElement;
      const focused = current.contains(active);
      const jobID = active.closest?.('[data-download-job]')?.dataset.downloadJob;
      const control = active.dataset?.downloadFocus;
      const scroll = [window.scrollX, window.scrollY];
      for (const oldJob of current.querySelectorAll('[data-download-job]')) {
        const nextJob = [...replacement.querySelectorAll('[data-download-job]')].find((job) => job.dataset.downloadJob === oldJob.dataset.downloadJob);
        if (!nextJob) continue;
        // Keep in-flight event handlers and disabled buttons attached to their job.
        if (oldJob.querySelector('[data-download-device]:disabled,form[data-removing="true"]')) nextJob.replaceWith(oldJob);
        else if (oldJob.querySelector('details[open]')) nextJob.querySelector('details')?.setAttribute('open', '');
      }
      current.replaceWith(replacement);
      if (focused) {
        const target = [...replacement.querySelectorAll('[data-download-focus]')].find((node) =>
          node.dataset.downloadFocus === control && node.closest('[data-download-job]')?.dataset.downloadJob === jobID && !node.disabled);
        if (target) target.focus({ preventScroll: true });
        else replacement.querySelector('h1')?.focus();
        if (target) window.scrollTo(...scroll);
      } else window.scrollTo(...scroll);
      if (replacement.dataset.downloadsPending !== "true") stopDownloadsPoll();
      await bindOfflineDownloads();
      bindLiveDownloads();
    }
  } catch (_) {}
  finally {
    refreshingDownloads = false;
    if (downloadsRefreshQueued) { downloadsRefreshQueued = false; void refreshDownloads(); }
  }
};
const startDownloadsPoll = () => {
  if (document.querySelector("#downloads")?.dataset.downloadsPending !== "true") { stopDownloadsPoll(); return; }
  if (!downloadsPoll) downloadsPoll = setInterval(refreshDownloads, 3000);
};
function bindLiveDownloads() {
  if (!document.querySelector("#downloads") || downloadsEvents) return;
  if (!("EventSource" in window)) { startDownloadsPoll(); return; }
  downloadsEvents = new EventSource("/api/v1/events");
  downloadsEvents.addEventListener("download.updated", refreshDownloads);
  downloadsEvents.onopen = stopDownloadsPoll;
  downloadsEvents.onerror = startDownloadsPoll;
}

async function renderOfflineLibrary() {
  const target = document.querySelector("[data-offline-library]");
  if (!target) return;
  if (!hasOfflineStorage) {
    const message = document.createElement("p");
    message.textContent = offlineMessage("offlineStorageUnsupported", "This browser cannot store offline media safely");
    target.replaceChildren(message);
    return;
  }
  const profile = activeOfflineProfile();
  let jobs;
  try { jobs = (await getOfflineJobs()).filter((job) => job.profileID === profile && job.state === "ready" && job.readyOffline); }
  catch (_) {
    const message = document.createElement("p");
    message.textContent = offlineMessage("offlineStorageUnsupported", "This browser cannot store offline media safely");
    target.replaceChildren(message);
    return;
  }
  const requested = new URL(location.href).searchParams.get("job");
  const selected = jobs.find((job) => job.id === requested);
  target.replaceChildren();
  if (selected) {
    const back = document.createElement("a");
    back.href = "/offline";
    back.className = "button quiet";
    back.textContent = offlineMessage("offlineBack", "Back to downloads");
    target.append(back);
    const status = document.createElement("p");
    status.setAttribute("role", "status");
    const heading = document.createElement("h2");
    heading.textContent = selected.title;
    const media = document.createElement(selected.quality === "audio" ? "audio" : "video");
    media.controls = true;
    media.playsInline = true;
    media.setAttribute("aria-label", selected.title);
    bindOfflineProgress(media, selected, status);
    bindOfflinePlaybackEvidence(media, selected);
    media.src = `/offline-media/${encodeURIComponent(profile)}/${encodeURIComponent(selected.id)}`;
    if (media instanceof HTMLVideoElement) {
      const stage = document.createElement("div");
      stage.className = "media-stage";
      stage.append(media);
      target.append(heading, stage);
    } else target.append(heading, media);
    target.append(status);
    return;
  }
  if (!jobs.length) {
    const message = document.createElement("p");
    message.textContent = profile
      ? offlineMessage("offlineNoReady", "No downloads are ready on this device for this Viewer Profile.")
      : offlineMessage("offlineSelectProfile", "Open Kinosail online and choose a Viewer Profile first.");
    target.append(message);
    return;
  }
  const list = document.createElement("ul");
  for (const job of jobs) {
    const item = document.createElement("li");
    const link = document.createElement("a");
    link.href = `/offline?job=${encodeURIComponent(job.id)}`;
    link.textContent = `${job.title} · ${job.quality} · ${job.playbackAgent === navigator.userAgent.slice(0, 512) ? offlineMessage("offlineReady", "Ready offline on this device") : offlineMessage("offlineVerified", "Saved and verified. Play to check compatibility.")}`;
    item.append(link);
    list.append(item);
  }
  target.append(list);
}

const bindOfflineChannel = () => {
  if (offlineChannel || !("BroadcastChannel" in window)) return;
  offlineChannel = new BroadcastChannel("kinosail-offline");
  offlineChannel.addEventListener("message", ({data}) => {
    if (data?.type === "cancel") cancelOfflineTransfer(data);
    else showOfflineStatus(data?.jobID, data?.detail || {});
  });
};
bindOfflineChannel();
bindOfflineDownloads();
bindLiveDownloads();
void syncOfflineProgress();
renderOfflineLibrary().catch(() => {});
addEventListener("pagehide", () => {
  for (const owner of offlineTransfers.values()) owner.controller.abort();
  closeOfflineDatabase();
  downloadsEvents?.close();
  downloadsEvents = undefined;
  offlineChannel?.close();
  offlineChannel = undefined;
  stopDownloadsPoll();
});
addEventListener("pageshow", ({persisted}) => {
  if (!persisted) return;
  bindOfflineChannel();
  bindOfflineDownloads();
  bindLiveDownloads();
  renderOfflineLibrary().catch(() => {});
});
document.body.addEventListener("htmx:after:swap", bindOfflineDownloads);
